# -*- coding: utf-8 -*-
"""
Created on Thu Jun 09 11:49:17 2016

@author: u505119
"""
from bs4 import BeautifulSoup
import pandas as pd
import re

path='C:/Users/U505119/Desktop/10_K/outt2101.csv'
frame = pd.read_csv(path)

level1 = re.compile(r'[RrsS][ea][vl][e]') 
level2 = re.compile(r'[RrCc][eu][ps][rt][eo]')
level3 = re.compile(r'[%]|[$]')
SenS1 = re.compile(r'[.!?][\s+][A-Z][^t][^dc][^.]')
SenS2 = re.compile(r'[(][1-3a-zA-Z][)]')
def FindRelevant(ltf):
    for Sentence in ltf:
        if level1.search(Sentence) != None:
            if level2.search(Sentence) != None:
                if level3.search(Sentence) != None:
                    if 'below' not in Sentence:
                        if 'as follows' not in Sentence:
                            if 'table' not in Sentence:
                                if Sentence.__len__()>100:
                                    print Sentence + '\n\n'

def Find_Pattern(Pattern,thingToFindIn,Print):
    Output=[]
    prev = 0
    for m in re.finditer(Pattern,thingToFindIn): # Ltd or Inc            
        Output.append(thingToFindIn[prev:m.start()].lstrip('. '))
        prev = m.start()
    Output.append(thingToFindIn[prev:].lstrip('. ').rstrip(' '))
    Output = filter(None, Output)
    #Output = list(set(Output))
    if Print:
        FindRelevant(Output)
    return Output
                                
frame = frame[pd.notnull(frame['fact'])]   
list_1=[]                   
for searchi in frame.ix[:,'fact']:
    if (searchi[0]=='<'):    
        #data=frame.ix[searchi,'fact']
        udata=searchi.decode("utf-8")
        asciidata=udata.encode("ascii","ignore")
        list_t=re.sub('<.*?>', ' ',asciidata)
        list_t=re.sub('&.{0,10}?;', '',list_t)
        prev = 0
        list_t=list_t.replace('\r',' ').replace('\t',' ').replace('\n',' ')
        list_t=re.sub(' +',' ',list_t)
        #list_1.extend(Find_Pattern(r'[.!?][\s*][A-Z][^t][^dc][^.]',list_t,False))
        temp=Find_Pattern(r'[.!?][\s*][A-Z][^t][^dc][^.]',list_t,False)
        for i in temp:
            temp_1=Find_Pattern(r'[ ][(][a-z1-9A-Z][)]',i,False)
        for i_2 in temp_1:
            if ('Ltd.' in i_2) or ('Inc.'in i_2):
                list_1.extend(Find_Pattern(r'[a-z0-9][.][A-Z)]',i_2,True))
            else:
                list_1.extend(Find_Pattern(r'[a-z0-9][.*][A-Z)]',i_2,True))            

















'''list_2=[]
for level2i in list_1:
    #list_2.extend(Find_Pattern(r'[ ][(][a-z1-9][)]',level2i,True))
    if ('Ltd.' in level2i) or ('Inc.'in level2i):
        list_2.extend(Find_Pattern(r'[a-z][.][A-Z)]',level2i,True))
    else:
        list_2.extend(Find_Pattern(r'[a-z][.*][A-Z)]',level2i,True))





temp=BeautifulSoup(frame.ix[searchi,'fact'])
list_t=u''
list_temp=temp.findAll()
new_list=[]
list_1=[]
for i in xrange(list_temp.__len__()):
    list_temp[i]=list_temp[i].name

[new_list.append(x) for x in list_temp if x not in new_list]
list_temp=[]


for pi_t in new_list:
    for pi in temp.findAll(pi_t):
        temp_obj= pi.text.encode('ascii', 'ignore').decode('ascii') in list_t        
        if not temp_obj:
            list_t= list_t +' '+ pi.text.encode('ascii', 'ignore').decode('ascii').strip()
    list_t=list_t+ '. ' 

for pi in temp.findAll(new_list[0]):
    list_t= list_t +' '+ pi.text.encode('utf-8', 'ignore').decode('utf-8').strip()
    #list_t=list_t+ '. ' '''
# (r'[.!?][\s*][A-Z(][a-z 1-9][^dc][^.]|[I][n][^c]'
#list_t=re.sub('&#160;',' ',list_t)
#list_t=re.sub('&nbsp;',' ',list_t)
#list_t.replace(u'\xc2', ' ')
#list_t=re.sub('\xc2',' ',list_t)
#list_t.replace(u'\xa0', ' ')
#list_t=re.sub('\xa0',' ',list_t)
#list_t=re.sub('' ',list_t)