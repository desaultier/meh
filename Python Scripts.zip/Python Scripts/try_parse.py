# -*- coding: utf-8 -*-
"""
Created on Mon May 30 20:21:40 2016

@author: danis
"""

df = pd.DataFrame([],columns  = ['elementId', 'contextId', 'unitId', 'fact', 'decimals', 'scale', 'sign', 'factid', 'ns'])

handle = open(PATH)

soup = BeautifulSoup(handle)
Found_xml=0
result = soup.findAll()
for Index_Search_XML in xrange(5):
    if 'xbrl' in result[Index_Search_XML].name:
        print 'aIYa'
        Found_xml=Index_Search_XML
        break
    else:
        y=[]
        Keys=[]
# Entire content is between xbrl tags, attributes of the xbrl tag
# is a dictionary containing ns values
"""tag_xbrl=soup.findAll('xbrl')
if tag_xbrl.__len__() != 0:
    y = tag_xbrl[0].attrs
    Keys=y.keys()
else:
    y=[]
    Keys=[]
"""
y=result[Found_xml].attrs
Keys=y.keys()
# Copy name to remove 'xlmns:' from key names
key_copy=Keys
# stripping xlmns and removing Null elements
for index in xrange(key_copy.__len__()):
    key_copy[index]=key_copy[index].lstrip('xlmns:')
key_copy = filter(None, key_copy)
# Finding and feeding values to output dataframe
for i in xrange(0, result.__len__()):
    tag = result[i].attrs 
    if 'contextref' in tag.keys():
        sen1 = result[i].name # ElementId
            
        if tag.has_key('contextref'):
            sen2 = tag['contextref']
        else:
            sen2 = None
            
        if tag.has_key('unitref'):
            sen3 = tag['unitref']
        else:
            sen3 = None
        # converting text from unicode to ascii
        if result[i].text.encode('ascii','ignore') != None:
            t = result[i].text.encode('ascii','ignore').split('\n')
            te = ''.join(t)
            sen4 = te 
        else:
            sen4 = None
            
        if tag.has_key('decimals'):
            sen5 = tag['decimals']
        else:
            sen5 = None
                
        if tag.has_key('scale'):
            sen6 = tag['scale']
        else:
            sen6 = None
                
        if tag.has_key('sign'):
            sen7 = tag['sign']
        else:
            sen7 = None
                
        if tag.has_key('factid'):
            sen8 = tag['factid']
        else:
            sen8 = None
        # Mapping Keys to links
        if Keys.__len__():  
            for i_keys in Keys:
                if tag.has_key(i_keys):
                    sen9=y[i_keys]
                else:
                    # if the tag name is "us-gaap:xyz" we extract "us-gaap"
                    if result[i].name.split(':',1)[0] in key_copy:
                        temp_key='xmlns:'+result[i].name.split(':',1)[0]
                        #print temp_key
                        if y.has_key(temp_key):
                            sen9 = y[temp_key]
                            #print '0'
                    else:
                        sen9 = None
        else:
            sen9= None
        # Adding to dataframe
        df.loc[i] = [sen1,sen2,sen3,sen4,sen5,sen6,sen7,sen8,sen9]
df=df.reset_index(drop=True)

