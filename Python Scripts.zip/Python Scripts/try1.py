# -*- coding: utf-8 -*-
"""
Created on Tue May 24 14:19:03 2016

@author: u505119
"""

from bs4 import BeautifulSoup
import lxml
import bs4
from pandas import DataFrame
import csv
import unicodedata

path = 'C:/Users/u505119/Desktop/hormel_10k.xml'
data=BeautifulSoup(open(path))
