# -*- coding: utf-8 -*-
"""
Created on Wed Jun 01 13:17:14 2016

@author: u505119
"""


from bs4 import BeautifulSoup
import pandas as pd
import re

path='C:/Users/U505119/Desktop/hormel_10k.xml'
#path='C:/Users/U505119/Desktop/nat-20151231.xml'
#path='C:/Users/u505119/Desktop/sndk-20160103.xml'
#path='C:/Users/u505119/Desktop/clb-20151231.xml'
#path='C:/Users/U505119/Desktop/hsic-20151226.xml'
#path='C:/Users/u505119/Desktop/nick-20151231.xml'
#path='C:/Users/u505119/Desktop/rl-20120331.xml'

df = pd.DataFrame([],columns  = ['elementId', 'contextId', 'unitId', 'fact', 'decimals', 'scale', 'sign', 'factid', 'ns','length'])
df_sen = pd.DataFrame([],columns  = ['fact'])
loc_i=0
handle = open(path)
soup = BeautifulSoup(handle)
Found_xml=0
result = soup.findAll()
for Index_Search_XML in xrange(5):
    if 'xbrl' in result[Index_Search_XML].name:
        print 'XML ns Values Extracted from ' + path.split('/')[-1]
        Found_xml=Index_Search_XML
        break
    else:
        y=[]
        Keys=[]
# Entire content is between xbrl tags, attributes of the xbrl tag
# is a dictionary containing ns values
y=result[Found_xml].attrs
Keys=y.keys()
# Copy name to remove 'xlmns:' from key names
key_copy=Keys
# stripping xlmns and removing Null elements
for index in xrange(key_copy.__len__()):
    key_copy[index]=key_copy[index].lstrip('xlmns:')
key_copy = filter(None, key_copy)
# Finding and feeding values to output dataframe
for i in xrange(0, result.__len__()):
    tag = result[i].attrs 
    if 'contextref' in tag.keys():
        sen1 = result[i].name # ElementId
        #sen10=sen1.__len__()
        if tag.has_key('contextref'):
            sen2 = tag['contextref']
        else:
            sen2 = None 
        if tag.has_key('unitref'):
            sen3 = tag['unitref']
        else:
            sen3 = None
        if result[i].text.encode('utf-8','ignore') != None:
                t = result[i].text.encode('utf-8','ignore').split('\n')
                te = ''.join(t)
                sen4 = te
                sen10=sen4.__len__()
                if sen10:
                    if sen4[0]=='<':
                      df_sen.loc[loc_i] = [sen4]
                      loc_i=loc_i+1
        else:
            sen4 = None
            sen10= None
        """# converting text from unicode to ascii
        temp = result[i].text.encode('ascii')
        #sentences = re.split(r' *[\.\?!][\'"\)\]]* *', text)
        #sentences = re.split(r' *[\.\?!][\'"\)\]]* *', text)[.!?]
        #act = str(temp).replace(" ","")
        
        if temp.__len__():
            sen4=re.sub('<.*?>', '', temp)
            sen4 = sen4.replace('\r','').replace('\t','').replace('\n','')
            sen4=sen4.replace('&#x2019;','')
            sen4=sen4.replace('&nbsp;',' ')
            sen10=sen4.__len__()
            #working=tokenize.sent_tokenize(sen4)
            #temporary=re.search(r'[.!?][\s+][\w]',sen4)
            #working=re.split(r'[.!?][\s+][\w]', sen4)
            #working=re.split(r' *[\.\?!][\'"\)\]]* *', sen4)
            prev = 0            
            list_1=[]
            for m in re.finditer(r'[.!?][\s+][0-9A-Z]',sen4):
                list_1.append(sen4[prev:m.start()].lstrip('. '))
                prev = m.start()
            list_1.append(sen4[prev:].lstrip('. ').rstrip(' '))
            for Sentence in list_1:
                #if  re.findall('estimate',Sentence):               
                if ((('%' or'$') and '20')and ('approximately'or 'Co.' or 'sales' or 'revenue')) in Sentence.lower():
                    #Sentence=Sentence.replace('&nbsp;',' ')
                    df_sen.loc[loc_i] = [Sentence]
                    loc_i=loc_i+1
        else:
            sen4=None
            sen10=None
        """
        if tag.has_key('decimals'):
            sen5 = tag['decimals']
        else:
            sen5 = None
        if tag.has_key('scale'):
            sen6 = tag['scale']
        else:
            sen6 = None
        if tag.has_key('sign'):
            sen7 = tag['sign']
        else:
            sen7 = None
        if tag.has_key('factid'):
            sen8 = tag['factid']
        else:
            sen8 = None
        # Mapping Keys to links
        if Keys.__len__():  
            for i_keys in Keys:
                if tag.has_key(i_keys):
                    sen9=y[i_keys]
                else:
                    # if the tag name is "us-gaap:xyz" we extract "us-gaap"
                    if result[i].name.split(':',1)[0] in key_copy:
                        temp_key='xmlns:'+result[i].name.split(':',1)[0]
                        #print temp_key
                        if y.has_key(temp_key):
                            sen9 = y[temp_key]
                            #print '0'
                    else:
                        sen9 = None
        else:
            sen9= None
        # Adding to dataframe
        df.loc[i] = [sen1,sen2,sen3,sen4,sen5,sen6,sen7,sen8,sen9,sen10]

df=df.reset_index(drop=True)
df=df.sort(['length'], ascending=0)
df=df.reset_index(drop=True)
working=df.ix[0,'fact']

list_t=[]
for searchi in xrange(df_sen.__len__()):
    temp=BeautifulSoup(df_sen.ix[searchi,'fact'])
    if temp.font !=None:
        list_t.append(temp.font.text.strip())
    #for string in soup.stripped_strings:
    #    print(repr(string))
    if temp.div !=None:
        list_t.append(temp.div.text.strip())
    if temp.p !=None:
        list_t.append(temp.p.text.strip())
    if temp.html != None:
        list_t.append(temp.html.text.strip())
    if temp.b != None:
        list_t.append(temp.b.text.strip())
    if temp.i != None:
        list_t.append(temp.i.text.strip())
    
    #if temp.p!=None:
    #    print temp.p.string
    #if temp.b!=None:
    #    print temp.b.string

for divs in xrange(list_t.__len__()):
    list_t[divs]=list_t[divs].replace('\r','').replace('\t',' ')
    
prev = 0
list_1=[]
for paragraphs in xrange(list_t.__len__()):
    list_t[paragraphs]=list_t[paragraphs].replace(u'\xa0', ' ').encode('utf-8')
    list_t[paragraphs]=re.sub('[\xa0]',' ',list_t[paragraphs])
    list_t[paragraphs]=re.sub(' +',' ',list_t[paragraphs])
    for m in re.finditer(r'[.!?][\s+][A-Z]',list_t[paragraphs]):
        list_1.append(list_t[paragraphs][prev:m.start()].lstrip('. '))
        prev = m.start()
    list_1.append(list_t[paragraphs][prev:].lstrip('. ').rstrip(' '))
list_1 = filter(None, list_1)
for Sentence in list_1:
                #if  re.findall('estimate',Sentence):               
                if ((('%' or '$') or '20')and ('approximately'or 'Co.' or 'sales' or 'revenue'or 'fiscal')) in Sentence.lower():
                    #Sentence=Sentence.replace('&nbsp;',' ')
                    #df_sen.loc[loc_i] = [Sentence]
                    #loc_i=loc_i+1
                    print Sentence + '\n\n'
"""   
df_sen.__len__()
p=re.compile(r'[.!?][\s+][0-9A-Z]')
temp=p.findall(working)
prev = 0
list_1=[]

for m in re.finditer(r'[.!?][\s+][0-9A-Z]',working):
    list_1.append(working[prev:m.start()].lstrip('. '))
    prev = m.start()
list_1.append(working[prev:].lstrip('. '))

#working1=re.split(r'[.!?][\s+]', working)


for  indexes in xrange(working1.__len__()-2):
    if working1[indexes+1].__len__() != None:
        if working1[indexes+1][0].isupper():
            working1[indexes]=working1[indexes]+'. '+ working1[indexes+1]
            working1[indexes+1]=None
    working1=filter(None, working1)

if result[i].text.encode('ut','ignore') != None:
    t = result[i].text.encode('ascii','ignore').split('\n')
    temp = str(t).repl            
    te = ''.join(t)
    te=re.sub('<.*?>', '', te)
    te=re.sub('\\\\W', '', te)
    sen4=sen4.replace(' ','')
    sen10=sen4.__len__()
"""