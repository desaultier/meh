# -*- coding: utf-8 -*-
"""
Created on Wed Jun 15 14:28:11 2016

@author: u505119
"""
import nltk.data
import re

content=frame.loc[1,'fact']
text=CleanUp(content)

sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
#re.sub(r'([a-z0-9_])(.)([A-Z])', r"\1\2", list_t)
extra_abbreviations = ['no'] 
sent_detector._params.abbrev_types.update(extra_abbreviations) 
#custom_tknzr._params.abbrev_types.update(extra_abbreviations) 
#list_2=custom_tknzr.tokenize(text)
list_2=sent_detector.tokenize(text.strip(),realign_boundaries=True)
print list_2
