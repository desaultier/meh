# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 12:11:34 2016

@author: u505119
"""

def lift_chart(DF,T,F):
    deciles=DF.sort('y', ascending=0)
    deciles=deciles.reset_index(drop=True)
    #deciles=deciles.loc[deciles.y>C,]
    length=deciles.__len__()
    sub=int(length/10)
    rem=int(length%10)
    popu=[sub for item in xrange(10) if 1]
    popu[:rem]=[(sub+1) for item in xrange(rem) if 1]
    last=0
    lift=pd.DataFrame(columns=['0','1','GT','PercentRights','PercentWrongs','PercentPopulation','CumPercentRight','CumPercentPop','LiftAtdecile','TotalLift'])
    cumr=0
    cumw=0    
    for cin in xrange(10):
        t0=0
        t1=0
        #y_scoresl=[]
        end=last+popu[cin]
        for i in xrange(last,end):
            if deciles.loc[i,'actual']=='Yes':
                t1+=1
            else:
                t0+=1
        t=t0+t1
        cumr+=t1
        cumw+=t0
        last=end
        pr=(t1*100)/T
        pw=(t0*100)/F
        pp=(t*100)/length
        pcr=(cumr*100)/T
        pcp=(end*100)/length
        ld=pr*pp
        cld=pcr*pcp
        lift.loc[cin]=[t0,t1,t,pr,pw,pp,pcr,pcp,ld,cld]
    plt.figure()
    plt.plot(lift.CumPercentPop, lift.LiftAtdecile, label='Lift curve' )
    plt.plot([0, 100], [100, 100], 'k--')
    plt.xlim([10.0, 100.0])
    #plt.ylim([0.0, 220])
    plt.xlabel('Cumulative % of Polulation')
    plt.ylabel('Lift')
    plt.title('Lift Chart')
    plt.legend(loc="upper right")
    plt.show()
    return lift
a=lift_chart(frame,tt+ft,tf+ff)
