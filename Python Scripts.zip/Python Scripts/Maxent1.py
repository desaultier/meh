# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 13:31:54 2016

@author: u505119
"""
import pandas as pd
import nltk.data
from nltk.classify import maxent
import nltk
from nltk import word_tokenize
from nltk.corpus import stopwords
import string
from collections import Counter


list_stw= stopwords.words('english') + list(string.punctuation)
list_stw.remove('no')

path='C:/Users/U505119/Desktop/training.csv'
frame = pd.read_csv(path)
train_para=[]
for i in xrange(int(frame.__len__()*0.7)):
    text = frame.ix[i,'Phrase']
    [i for i in word_tokenize(text.lower()) if i not in list_stw]
    train_para.extend([i for i in word_tokenize(text.lower()) if ((i not in list_stw) or ((',' in i) or ('.' in i)))])
#train_para=list(set(train))
train_para=[item for item in train_para if not ((',' in item) or ('.' in item))]
train_para=[item for item in train_para if not item.isdigit()]
train_para=[item for item in train_para if (len(item)>1)]
train_para=Counter(train_para).items()
train_para=sorted(train_para, key=lambda x: x[1],reverse=True)
train_para=[item for item in train_para if (item[1]>50)]
answer=[]

train=[]
for i in xrange(int(frame.__len__()*0.7)):
    feature={}
    for parai in train_para:
        if parai[0] in frame.ix[i,'Phrase'].lower():
            value=True
        else:
            value=False
        feature[parai[0]]=value
    train.append((feature,frame.ix[i,'Indicator']))

test=[]
for i in xrange(int(frame.__len__()*0.7)+1,frame.__len__()):
    feature={}
    for parai in train_para:
        if parai[0] in frame.ix[i,'Phrase'].lower():
            value=True
        else:
            value=False
        feature[parai[0]]=value
    test.append(feature)

def test_maxent(algorithm):
     print str(algorithm)+ ' '
     try:
           classifier = nltk.classify.MaxentClassifier.train(train, algorithm, trace=0, max_iter=1000)
     except Exception as e:
         print('Error: %r' % e)
         return

     for featureset in test:
         pdist = classifier.prob_classify(featureset)
         answer.append([pdist.prob('Yes'), pdist.prob('No')])


test_maxent('IIS')
df=pd.DataFrame(columns=['actual','y','n'])

master=0
for i in xrange(int(frame.__len__()*0.7)+1,frame.__len__()):
    df.loc[master]=[frame.ix[i,'Indicator'],answer[master][0],answer[master][1]]
    master+=1
   

path='C:/Users/U505119/Desktop/check.csv'
df.to_csv(path, index=False,mode='wb', sep=',', header=True)

tt=0
tf=0
ff=0
ft=0
cutoff=0.8
for i in xrange(df.__len__()):
    if df.loc[i,'y']>cutoff:
        if df.loc[i,'actual']=='Yes':
            tt+=1
        else:
            tf+=1
    else:
        if df.loc[i,'actual']=='No':
            ff+=1
        else:
            ft+=1
accuracy= float(tt+ff)*100/float(tt+ff+tf+ft)
precision= float(tt)*100/float(tt+tf)
print accuracy

path='C:/Users/U505119/Desktop/checkr.csv'