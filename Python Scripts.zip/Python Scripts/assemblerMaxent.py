# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:47:40 2016

@author: u505119
"""

def Maxent(Sentences,Actuals,PathToSavedClassifier='C:/Users/U505119/Desktop/Maxent/classifier.pickle',PathToTrainPara='C:/Users/U505119/Desktop/Maxent/features.pickle',UseOptimumCutoff=True,cutoff=0.44572):
    import numpy as np
    from sklearn import metrics
    import pickle    
    #-----------------------------------------------------------------------
    #            Loading Classifier
    f = open(PathToSavedClassifier,'rb')   # Reading has to be done in 'rb' Mode
    classifier = pickle.load(f)
    f.close()
    #-----------------------------------------------------------------------
    #            Calculating Cutoff Specific Parameters
    
    f = open(PathToTrainPara,'rb')   # Reading has to be done in 'rb' Mode
    train_para = pickle.load(f)
    f.close()
    #-----------------------------------------------------------------------
    #            Prepairing Test Data 
    test=[]
    for i in xrange(Sentences.__len__()):
        feature={}
        for parai in train_para:
            if parai in Sentences[i].lower():
                value=True
            else:
                value=False
            feature[parai]=value
        test.append(feature)
    #-----------------------------------------------------------------------
    #            Classifying Test Data
    y_scores=[]
    for featureset in test:
        pdist = classifier.prob_classify(featureset)
        y_scores.append(pdist.prob('Yes'))
    y_true=[(item=='Yes') for item in Actuals if 1]  # Coverting from Yes No to True and False
    fpr, tpr, thresholds = metrics.roc_curve(y_true, y_scores)
    idx = np.argwhere(np.isclose((1-fpr)*1000,tpr*1000, atol=10)).reshape(-1)
    Optimal = round(thresholds[idx[idx.__len__()/2]],3)
    if UseOptimumCutoff:
        cutoff=Optimal
    output=[]
    for i in xrange(y_scores.__len__()):
        if y_scores[i]>cutoff:
            output.append(1)
        else:
            output.append(0)
    return output,y_scores

o,y=Maxent(Sentences=sentences['Phrase'],Actuals=frame['actual'])
#-----------------------------------------------------------------------------------------------
#                                END        OF         CODE
#-----------------------------------------------------------------------------------------------
