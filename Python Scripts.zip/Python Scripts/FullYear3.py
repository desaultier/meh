# -*- coding: utf-8 -*-
"""
Created on Thu Jun 09 11:49:17 2016

@author: u505119
"""
from bs4 import BeautifulSoup
import pandas as pd
import re

path='C:/Users/U505119/Desktop/10_K/outt2101.csv'
frame = pd.read_csv(path)

level1 = re.compile(r'[RrsS][ea][vl][e]') 
level2 = re.compile(r'[RrCc][eu][ps][rt][eo]')
level3 = re.compile(r'[%]|[$]')
def FindRelevant(ltf):
    for Sentence in ltf:
        if level1.search(Sentence) != None:
            if level2.search(Sentence) != None:
                if level3.search(Sentence) != None:
                    if 'below' not in Sentence:
                        if 'as follows' not in Sentence:
                            if 'table' not in Sentence:
                                if Sentence.__len__()>100:
                                    print Sentence + '\n\n'
                                
frame = frame[pd.notnull(frame['fact'])]
searchi=0L                       
for searchi in frame.ix[:,'fact']:
    if (searchi[0]=='<'):    
        #data=frame.ix[searchi,'fact']
        udata=searchi.decode("utf-8")
        asciidata=udata.encode("ascii","ignore")
        list_t=re.sub('<.*?>', ' ',asciidata)
        list_t=re.sub('&.{0,10}?;', '',list_t)
        prev = 0
        list_t=list_t.replace('\r',' ').replace('\t',' ').replace('\n',' ')
        #list_t=re.sub('&#160;',' ',list_t)
        #list_t=re.sub('&nbsp;',' ',list_t)
        #list_t.replace(u'\xc2', ' ')
        #list_t=re.sub('\xc2',' ',list_t)
        #list_t.replace(u'\xa0', ' ')
        #list_t=re.sub('\xa0',' ',list_t)
        #list_t=re.sub('' ',list_t)
        list_t=re.sub(' +',' ',list_t)
        list_1=[]
        for m in re.finditer(r'[.!?][\s+][A-Z][^t][^dc][^.]',list_t): # Ltd or Inc
                                
                list_1.append(list_t[prev:m.start()].lstrip('. '))
                prev = m.start()
                
        list_1.append(list_t[prev:].lstrip('. ').rstrip(' '))
        list_1 = filter(None, list_1)
        list_1 = list(set(list_1)) 
        FindRelevant(list_1)







'''temp=BeautifulSoup(frame.ix[searchi,'fact'])
list_t=u''
list_temp=temp.findAll()
new_list=[]
list_1=[]
for i in xrange(list_temp.__len__()):
    list_temp[i]=list_temp[i].name

[new_list.append(x) for x in list_temp if x not in new_list]
list_temp=[]


for pi_t in new_list:
    for pi in temp.findAll(pi_t):
        temp_obj= pi.text.encode('ascii', 'ignore').decode('ascii') in list_t        
        if not temp_obj:
            list_t= list_t +' '+ pi.text.encode('ascii', 'ignore').decode('ascii').strip()
    list_t=list_t+ '. ' 

for pi in temp.findAll(new_list[0]):
    list_t= list_t +' '+ pi.text.encode('utf-8', 'ignore').decode('utf-8').strip()
    #list_t=list_t+ '. ' '''
# (r'[.!?][\s*][A-Z(][a-z 1-9][^dc][^.]|[I][n][^c]'