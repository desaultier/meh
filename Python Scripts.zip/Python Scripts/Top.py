# -*- coding: utf-8 -*-
"""
Created on Fri May 27 13:08:57 2016

@author: u505119
"""
from pandas import DataFrame
from pandas import to_csv
from datetime import date
from pandas import read_table
from bs4 import BeautifulSoup
import pandas as pd
import urllib
import zipfile
import os.path
import os
import bs4
import csv
import unicodedata


def BasicParse(path):

    df = pd.DataFrame([],columns  = ['elementId', 'contextId', 'unitId', 'fact', 'decimals', 'scale', 'sign', 'factid', 'ns'])
    
    handle = open(path)
    
    soup = BeautifulSoup(handle)
    
    result = soup.findAll()
    # Entire content is between xbrl tags, attributes of the xbrl tag
    # is a dictionary containing ns values
    y = soup.findAll('xbrl')[0].attrs
    
    Keys=y.keys()
    # Copy name to remove 'xlmns:' from key names
    key_copy=Keys
    # stripping xlmns and removing Null elements
    for index in xrange(key_copy.__len__()):
        key_copy[index]=key_copy[index].lstrip('xlmns:')
    key_copy = filter(None, key_copy)
    # Finding and feeding values to output dataframe
    for i in xrange(0, result.__len__()):
        tag = result[i].attrs 
        if 'contextref' in tag.keys():
            sen1 = result[i].name # ElementId
                
            if tag.has_key('contextref'):
                sen2 = tag['contextref']
            else:
                sen2 = None
                
            if tag.has_key('unitref'):
                sen3 = tag['unitref']
            else:
                sen3 = None
            # converting text from unicode to ascii
            if result[i].text.encode('ascii','ignore') != None:
                t = result[i].text.encode('ascii','ignore').split('\n')
                te = ''.join(t)
                sen4 = te 
            else:
                sen4 = None
                
            if tag.has_key('decimals'):
                sen5 = tag['decimals']
            else:
                sen5 = None
                    
            if tag.has_key('scale'):
                sen6 = tag['scale']
            else:
                sen6 = None
                    
            if tag.has_key('sign'):
                sen7 = tag['sign']
            else:
                sen7 = None
                    
            if tag.has_key('factid'):
                sen8 = tag['factid']
            else:
                sen8 = None
            # Mapping Keys to links
            for i_keys in Keys:
                if tag.has_key(i_keys):
                    sen9=y[i_keys]
                else:
                    # if the tag name is "us-gaap:xyz" we extract "us-gaap"
                    if result[i].name.split(':',1)[0] in key_copy:
                        temp_key='xmlns:'+result[i].name.split(':',1)[0]
                        #print temp_key
                        if y.has_key(temp_key):
                            sen9 = y[temp_key]
                            #print '0'
                    else:
                        sen9 = None
            # Adding to dataframe
            df.loc[i] = [sen1,sen2,sen3,sen4,sen5,sen6,sen7,sen8,sen9]
    df=df.reset_index(drop=True)
    return df

base='ftp://ftp.sec.gov/edgar/full-index/'
destination='C:/Users/u505119/Desktop/Edgar'

df_path=DataFrame(columns=['Links'])

# creating a map to help navigate website and local directy easily
# in the form of YEAR/QTR/FILE
# takes record from 1993 to present year
for i_0 in xrange(2015,date.today().year+1):
    site=str(i_0)+'/'
    for k in xrange(4,5):
        df_path=df_path.append(DataFrame([site+'QTR'+str(k)+'/xbrl.zip'],columns=['Links']))

# because we appended, index for all will be 0 
df_path=df_path.reset_index(drop=True)

for i_1 in xrange(df_path.__len__()):
    # link: 'ftp://ftp.sec.gov/edgar/full-index/YEAR/QTR/xbrl.zip'
    # zipFilePath: 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/xbrl.zip'
    urllib.urlretrieve(base+df_path.ix[i_1,'Links'], destination+'/'+df_path.ix[i_1,'Links'])
    zipFilePath= destination+'/'+df_path.ix[i_1,'Links']
    # destDir: 'C:/Users/u505119/Desktop/EdgarYEAR/QTR/'
    destDir=destination+'/'+df_path.ix[i_1,'Links'].replace('xbrl.zip','')
    
    # zipFilePath: 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/xbrl.zip'
    zfile = zipfile.ZipFile(zipFilePath)
    # if the zip file has subfolders we make the subfolders and copy files to them
    for name in zfile.namelist():
        (dirName, fileName) = os.path.split(name)
        if fileName == '':
            # directory
            newDir = destDir + dirName
            if not os.path.exists(newDir):
                os.mkdir(newDir)
        else:
            # file
            fd = open(destDir + name, 'wb')
            fd.write(zfile.read(name))
            fd.close()
    zfile.close()
    # 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/name'
    a=read_table(destDir + '/' + name,delimiter='|',header=4)
    # Dropping dashes
    a=a.drop(0)
    # Getting paths to .zip files on sec.gov website
    for i_2 in xrange(1,a.__len__()):
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename'].replace('.txt', '')
        r = a.ix[i_2, 'Filename'].split('/')
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename'].replace('-', '')
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename']+'/'+ r[-1]+ '-xbrl.zip'
    a=a.reset_index(drop=True)
   
    for i_3 in xrange(a.__len__()):
        # Link: 'ftp://ftp.sec.gov/Link_in_a'
        # Destination : 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/filename_index.zip'
        urllib.urlretrieve('ftp://ftp.sec.gov/'+a.ix[i_3,'Filename'], destination+'/'+df_path.ix[i_1,'Links'].replce('.zip','_'+str(i_3)+'.zip'))
        zipFilePath_1= destination+'/'+df_path.ix[i_1,'Links'].replce('.zip','_'+str(i_3)+'.zip')
        destDir_1=destination+'/'+df_path.ix[i_1,'Links'].replace('xbrl.zip','')  
        zfile_1 = zipfile.ZipFile(zipFilePath_1)
        for name_1 in zfile_1.namelist():
            (dirName_1, fileName_1) = os.path.split(name_1)
            if fileName_1 == '':
                # directory
                newDir_1 = destDir_1 + '/' + dirName_1
                if not os.path.exists(newDir_1):
                    os.mkdir(newDir_1)
            else:
                # file
                fd_1 = open(destDir_1 + '/' + name_1, 'wb')
                fd_1.write(zfile_1.read(name_1))
                fd_1.close()
        zfile_1.close()
        
        List_to_select=zfile_1.namelist()
#        List_to_select=List_to_select.sort
        # List ia already sorted and so we select which ever is first but
        # ends in .xml
        for i_4 in List_to_select:
            if '.xml' in i_4:
                Name_to_parse=i_4
                break
            else:
                continue
        PATH=destDir_1 + '/' +Name_to_parse
        Temp_DF= BasicParse(PATH)
        
        Name_toWrite=destDir_1 + '/prsdData'+str(i_3//300)+'.csv'
        
        Temp_DF.to_csv(Name_toWrite, mode='a', index=False, sep='||', header=(i_3%300))
        
        
    
