# -*- coding: utf-8 -*-
"""
Created on Mon May 30 15:31:27 2016

@author: danis
"""
import urllib
import os
File='ftp://ftp.sec.gov/edgar/full-index/2011/QTR1/xbrl.zip'
directory= 'C:/Users/danis/Desktop/Edgar/QT1'
if not os.path.exists(directory):
    os.makedirs(directory)
urllib.urlretrieve('ftp://ftp.sec.gov/edgar/full-index/2011/QTR1/xbrl.zip',directory+'/xbrl.zip')