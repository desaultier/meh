# -*- coding: utf-8 -*-
"""
Created on Thu May 26 10:40:23 2016

@author: u505119

"""

from pandas import DataFrame
import pandas as pd
from pandas import read_table
path='C:/Users/u505119/Desktop/xbrl.idx'
a=read_table(path,delimiter='|',header=4)
a=a.drop(0)
#a=a.reset_index()

for i in xrange(1, a.__len__()):
    a.ix[i, 'Filename'] = a.ix[i, 'Filename'].replace('.txt', '')
    r = a.ix[i, 'Filename'].split('/')
    a.ix[i, 'Filename'] = a.ix[i, 'Filename'].replace('-', '')
    a.ix[i, 'Filename'] = 'ftp://ftp.sec.gov/'+a.ix[i, 'Filename']+'/'+ r[-1]+ '-xbrl.zip'
Forms_10k=a[a['Form Type']=='10-K']
Forms_10k=Forms_10k.reset_index()
Forms_10q=a[a['Form Type']=='10-Q']
Forms_10q=Forms_10q.reset_index()

"""
Files=a.Filename
for i in xrange(0, Files.__len__()):
    r = Files[i].split('/')
    Files[i]=r
    
"""