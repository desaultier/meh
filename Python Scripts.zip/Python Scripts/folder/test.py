# -*- coding: utf-8 -*-
"""
Created on Fri Jun 17 15:56:34 2016

@author: u505119
"""

import pandas as pd
import re
import glob
import nltk.data

path_m='C:\\Users\\U505119\\Desktop\\10_K\\'
Name_toWrite='C:/Users/U505119/Desktop/Parsed.csv'

#/////////////////////////////////////////////////////////
#                    Internal Variables
#/////////////////////////////////////////////////////////
#       Regular Expressions

#level1_1 = re.compile(r'[Aa]ccounted')
#level1a = re.compile(r'[RrCc][eu][ps][rt][eo]')
#contribute attribute represent account
level1_a = re.compile(r'[Cc]ontribute')
level1_d = re.compile(r'[Aa]ttribute')
level1_b = re.compile(r'[Aa]ccount')
level1_c = re.compile(r'[Rr]epresent')

level2_a = re.compile(r'[sS]ale') 
level2_b = re.compile(r'[Rr]evenue')

level3 = re.compile(r'%|percent')

#level7 = re.compile('no customer')
#SenS1 = re.compile(r'[.!?][\s+][A-Z][^t][^dc][^.]')
#SenS2 = re.compile(r'[( ][1-3a-zA-Z][ *][)t][d*c*]')

#       Initialization
df=pd.DataFrame(columns=['qtr','form_type','Company_Name','CIK','Date','Path','Category','Fact'])
master_loci=0  


sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
extra_abbreviations = ['no'] 
sent_detector._params.abbrev_types.update(extra_abbreviations) 

paths= glob.glob(path_m+"*.csv")

def CleanUp(content):
    udata=content.decode("utf-8")
    asciidata=udata.encode("ascii","ignore")
    list_t=re.sub('<.*?>', ' ',asciidata)
    list_t=re.sub('&.{0,10}?;', ' ',list_t)
    list_t=list_t.replace('\r',' ').replace('\t',' ').replace('\n',' ')
    list_t=re.sub(' +',' ',list_t)
    #re.sub(r'([a-z0-9])(.)([A-Z])', r"\1\. \2", list_t)
    #list_t=re.sub('\.','. ',list_t)
    return list_t

for i_p in xrange(paths.__len__()):
    
    frame = pd.read_csv(paths[i_p])
    frame = frame[pd.notnull(frame['fact'])] 
              
    for searchi in xrange(frame.ix[:,'fact'].__len__()):
        try:    
            content=frame.loc[searchi,'fact']
            #if (content[0]=='<'):    
                #data=frame.ix[searchi,'fact']
            list_t=CleanUp(content)
            list_1=[]
            list_1.append(Find_Pattern('[\.]\s*[A-Z(]',list_t,True,searchi))
        except:
            continue
    #df.drop_duplicates('Fact', take_last=True)
    #df=df.reset_index(drop=True)
    print str(i_p+1) +'/'+str(paths.__len__())+ " done"
df.drop_duplicates(subset='Fact',take_last=True)
df=df.reset_index(drop=True)
df.to_csv(Name_toWrite, index=False,mode='wb', sep=',', header=True)