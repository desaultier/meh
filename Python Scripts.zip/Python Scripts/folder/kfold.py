# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 14:59:29 2016

@author: u505119
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 13:31:54 2016

@author: u505119
"""
import pandas as pd
import nltk
import nltk.data
from nltk.classify import maxent
from nltk import word_tokenize
from nltk.corpus import stopwords
import pickle
import string
from collections import Counter

#/////////////////////////////////////////////////////////
#                    User Variables
#/////////////////////////////////////////////////////////
algorithm='IIS'
num=0
PercentToTrain=0.7
MinCountLimit=100
MainPath='C:/Users/U505119/Desktop/24July2016/'
pathOfTrainingData='C:/Users/U505119/Desktop/training.csv'
PathToStoreClassifier=MainPath+'my_classifier'+str(num)+'.pickle'
pathToStoreResult=MainPath+'check.csv'
PathToTrainPara=MainPath+'TrainPara.txt'

#////////////////////////////////////////////////////////
#                    Main program
#//////////////////////////////////////////////////////// 

    df = pd.read_csv(pathOfTrainingData)
    train_para=[]
    
    #-----------------------------------------------------------------------
    #            Prepairing Training Data 
    train=[]
    for i in xrange(int(df.__len__()*PercentToTrain)):
        feature={}
        for parai in train_para:
            if parai in df.ix[i,'Phrase'].lower():
                value=True
            else:
                value=False
            feature[parai]=value
        train.append((feature,df.ix[i,'Indicator']))
        
    #-----------------------------------------------------------------------
    #            Prepairing Test Data 
    test=[]
    for i in xrange(int(df.__len__()*PercentToTrain)+1,df.__len__()):
        feature={}
        for parai in train_para:
            if parai in df.ix[i,'Phrase'].lower():
                value=True
            else:
                value=False
            feature[parai]=value
        test.append(feature)
    
    #-----------------------------------------------------------------------
    #            Training Classifier 
    print str(algorithm)
    try:
      classifier = nltk.classify.MaxentClassifier.train(train, algorithm, trace=0, max_iter=1000)
    except Exception as e:
        print('Error: %r' % e)
    # Until here------------------------------------------
    #-----------------------------------------------------------------------
    #            Storing Classifier 
    
    f = open(PathToStoreClassifier, 'wb')
    pickle.dump(classifier, f) #WAITTTTTTTTTT
    f.close()
    
    #-----------------------------------------------------------------------
    #            Classifying Test Data
    answer=[]
    for featureset in test:
        pdist = classifier.prob_classify(featureset)
        answer.append([pdist.prob('Yes'), pdist.prob('No')])
    
    frame=pd.DataFrame(columns=['actual','y','n'])
    master=0
    for i in xrange(int(df.__len__()*0.7)+1,df.__len__()):
        frame.loc[master]=[df.ix[i,'Indicator'],answer[master][0],answer[master][1]]
        master+=1
       
    df.to_csv(pathToStoreResult, index=False,mode='wb', sep=',', header=True)
    
    y_scores=frame.loc[:,'y']   # Model given probability of yes
    y_true =frame.loc[:,'actual'] # Actual Yes or No 
    y_scores = np.array(y_scores)
    y_true=[(item=='Yes') for item in y_true if 1]  # Coverting from Yes No to True and False
    y_true_count=Counter(y_true).items() # Clusters True and false together in an tuple and gives its freq
    if y_true_count[0][0]: 
        yT=y_true_count[0][1]
        fT=y_true_count[1][1]
    else:
        yT=y_true_count[1][1]
        fT=y_true_count[0][1]
    
    Score=str(round(roc_auc_score(y_true, y_scores),3)) # Area under ROC
    # Score Ranges and Model Evaluation
    # 0.90-1 = excellent (A)
    # 0.80-.90 = good (B)
    # 0.70-.80 = fair (C)
    # 0.60-.70 = poor (D)
    # 0.50-.60 = fail (F)
    
    fpr, tpr, thresholds = metrics.roc_curve(y_true, y_scores)
    a=LiftGainTable(frame,yT,fT) # yT= Number of Sentences Actually a Yes , fT= Number of sentences Actually a No 
    idx = np.argwhere(np.isclose((1-fpr)*1000,tpr*1000, atol=10)).reshape(-1)
    Optimal = thresholds[idx[idx.__len__()/2]]
    
    # Nomenclature: ModelPrediction Actual
    tt=0 # Model predicts True and is Actually True
    tf=0 # Model predicts True but is Actually False
    ff=0 # Model predicts False and is Actually False
    ft=0 # Model Predicts False but is Aactually True
    
    if UseOptimumCutoff:
        cutoff=Optimal
    
    for i in xrange(frame.__len__()):
        if frame.loc[i,'y']>cutoff:
            
            if frame.loc[i,'actual']=='Yes':
                tt+=1
            else:
                tf+=1
        else:
            if frame.loc[i,'actual']=='No':
                ff+=1
            else:
                ft+=1
    
    # How parameters are calculated: http://www.analyticsvidhya.com/wp-content/uploads/2015/01/Confusion_matrix.png
    #                               Definitions:
    # Accuracy : the proportion of the total number of predictions that were correct.
    # Positive Predictive Value or Precision : the proportion of positive cases that were correctly identified.
    # Negative Predictive Value : the proportion of negative cases that were correctly identified.
    # Sensitivity or Recall : the proportion of actual positive cases which are correctly identified.
    # Specificity : the proportion of actual negative cases which are correctly identified.
    accuracy= str(round(float(tt+ff)*100/float(tt+ff+tf+ft),2))
    precision= str(round(float(tt)*100/float(tt+tf),2)) # Same as Positive Predicted Value
    sensitivity= str(round(float(tt)*100/float(tt+ft),2))
    specificity= str(round(float(ff)*100/float(tf+ff),2))
    npv=str(round(float(ff)*100/float(ft+ff),2)) # Negative predicted value
    
    #-----------------------------------------------------------------------
    #            Calculations of Model Metrics
    
    print '\nConfusion Matrix with threshold as: '+ str(cutoff)+'\n'
    print '-----------------------------------------------------------\n'
    print '\t  Actual\t\n'
    print 'Model\tYes\tNo\t\n'
    print 'Yes\t'+str(tt)+'\t'+str(tf)+'\t\t'+'Precision: '+precision+'\n'
    print 'No\t'+str(ft)+'\t'+str(ff)+'\t\t'+'NPV: '+npv+'\n'
    print 'Sensitivity:\tSpecificity:\tAccuracy:\n'
    print sensitivity+'\t\t'+specificity+'\t\t'+accuracy+'\n'
    print '-----------------------------------------------------------\n'
    print 'Model Evaluation Metrics\n'
    print 'ROC Score: ' +Score
    ShowTables(ROC,SS,L,G)
    print '-----------------------------------------------------------\n'
    print 'Optimal Cutoff: '+str(Optimal)+'\n'
#-----------------------------------------------------------------------------------------------
#                                END        OF         CODE
#-----------------------------------------------------------------------------------------------





















#path='C:/Users/U505119/Desktop/checkr.csv'

'''

import pickle
f = open('C:/Users/U505119/Desktop/my_classifier'+str()+'.pickle', 'wb')
pickle.dump(classifier, f)
f.close()



import pickle
f = open('my_classifier.pickle', 'rb')
classifier = pickle.load(f)
f.close()
'''