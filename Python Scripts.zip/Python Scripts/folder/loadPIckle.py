# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 09:33:55 2016

@author: u505119
"""

import pickle
frame = pd.read_csv(pathOfTrainingData)
PathToStoreClassifier='C:/Users/u505119/Desktop/22July2016/my_classifier0.pickle'
f = open('my_classifier.pickle', 'rb')
classifier = pickle.load(f)
f.close()