# -*- coding: utf-8 -*-
"""
Created on Mon May 23 15:06:54 2016

@author: U505119
"""

path='C:/Users/u505119/Desktop/mtcars.xlsx'
from pandas import read_excel
import pandas as pd
# Reading Data
data=read_excel(path,'mtcars',skiprows=1,has_index_names=None)
#Removing NaN as column name of cars
i=data.columns
i=i.tolist()
i[0]='Model'
data.columns=i

make=read_excel(path,'make')
data=data.merge(make,on='Model',how='inner')
# Grouping 
group=data.groupby(by='Make')
# Statistical Analysis
groupMean=group.mean()
groupMedian=group.median()

groupMode=group.apply(pd.DataFrame.mode)
groupMode=groupMode.drop((u'Mercidez', 1L)) # Selecting one Mode
groupMode=groupMode.drop('Model',axis=1) # removing Model column
groupMode.index=groupMode['Make'] #making index same as Make column for concat function
groupMode=groupMode.drop('Make',axis=1) 
# Renaming
mean_list=['mpgMean','cylMean','dispMean','hpMean','dratMean','wtMean','qsecMean','vsMean','amMean','gearMean','carbMean']
groupMean.columns=mean_list
median_list=['mpgMedian','cylMedian','dispMedian','hpMedian','dratMedian','wtMedian','qsecMedian','vsMedian','amMedian','gearMedian','carbMedian']
groupMedian.columns=median_list
mode_list=['mpgMode','cylMode','dispMode','hpMode','dratMode','wtMode','qsecMode','vsMode','amMode','gearMode','carbMode']
groupMode.columns=mode_list
# Final 
Result= pd.concat((groupMean,groupMedian,groupMode),axis='inner')
Result=Result.reindex_axis(['mpgMean','mpgMedian','mpgMode','cylMean','cylMedian','cylMode','dispMean','dispMedian','dispMode','hpMean','hpMedian','hpMode','dratMean','dratMedian','dratMode','wtMean','wtMedian','wtMode','qsecMean','qsecMedian','qsecMode','vsMean','vsMedian','vsMode','amMean','amMedian','amMode','gearMean','gearMedian','gearMode','carbMean','carbMedian','carbMode'],axis=1)
