# -*- coding: utf-8 -*-
"""
Created on Fri May 27 13:08:57 2016

@author: u505119
"""
from pandas import DataFrame
from datetime import date
from pandas import read_table
from bs4 import BeautifulSoup
import pandas as pd
import urllib
import zipfile
import os.path
import os
import bs4
import csv
import unicodedata


def BasicParse(path):

    df = pd.DataFrame([],columns  = ['elementId', 'contextId', 'unitId', 'fact', 'decimals', 'scale', 'sign', 'factid', 'ns'])
    
    handle = open(path)
    
    soup = BeautifulSoup(handle)
    
    result = soup.findAll()
    y = soup.findAll('xbrl')[0].attrs

    for i in xrange(0, result.__len__()):
        tag = result[i].attrs
        sen1 = result[i].name
            
        if tag.has_key('contextref'):
            sen2 = tag['contextref']
        else:
            sen2 = None
        if tag.has_key('unitref'):
            sen3 = tag['unitref']
        else:
            sen3 = None
        if result[i].text.encode('ascii','ignore') != None:
            t = result[i].text.encode('ascii','ignore').split('\n')
            te = ''.join(t)
            sen4 = te 
        else:
            sen4 = None
        if tag.has_key('decimals'):
            sen5 = tag['decimals']
        else:
            sen5 = None
                
        if tag.has_key('scale'):
            sen6 = tag['scale']
        else:
            sen6 = None
                
        if tag.has_key('sign'):
            sen7 = tag['sign']
        else:
            sen7 = None
                
        if tag.has_key('factid'):
            sen8 = tag['factid']
        else:
            sen8 = None

        if tag.has_key('xmlns'):
            sen9 = y['xmlns']
        elif 'link' in result[i].name:
            sen9 = y['xmlns:link']
        elif 'dei' in result[i].name:
            sen9 = y['xmlns:dei']
        elif 'hrl' in result[i].name:
            sen9 = y['xmlns:hrl']
        elif 'us-gaap' in result[i].name:
            sen9 = y['xmlns:us-gaap']
        elif 'xbrli' in result[i].name:
            sen9 = y['xmlns:xbrli']
        elif 'xbrldi' in result[i].name:
            sen9 = y['xmlns:xbrldi']
        elif 'xlink' in result[i].name:
            sen9 = y['xmlns:xlink']
        elif 'xsi' in result[i].name:
            sen9 = y['xmlns:xsi']
        else:
            sen9 = None
            
        df.loc[i] = [sen1,sen2,sen3,sen4,sen5,sen6,sen7,sen8,sen9]
        
    return df


base='ftp://ftp.sec.gov/edgar/full-index/'
destination='C:/Users/u505119/Desktop/Edgar'
df_path=DataFrame(columns=['Links'])

for i_0 in xrange(1993,date.today().year+1):
    site=str(i_0)+'/'
    for k in xrange(1,5):
        df_path=df_path.append(DataFrame([site+'QTR'+str(k)+'/xbrl.zip'],columns=['Links']))
df_path=df_path.reset_index()

for i_1 in xrange(df_path.__len__()):
#    print i    
    urllib.urlretrieve(base+df_path.ix[i_1,'Links'], destination+'/'+df_path.ix[i_1,'Links'])
    zipFilePath= destination+'/'+df_path.ix[i_1,'Links']
    destDir=destination+'/'+df_path.ix[i_1,'Links'].replace('/xbrl.zip','')  
    zfile = zipfile.ZipFile(zipFilePath)
    for name in zfile.namelist():
        (dirName, fileName) = os.path.split(name)
        if fileName == '':
            # directory
            newDir = destDir + '/' + dirName
            if not os.path.exists(newDir):
                os.mkdir(newDir)
        else:
            # file
            fd = open(destDir + '/' + name, 'wb')
            fd.write(zfile.read(name))
            fd.close()
    zfile.close()
#    path='C:/Users/u505119/Desktop/xbrl.idx'
    a=read_table(destDir + '/' + name,delimiter='|',header=4)
    a=a.drop(0)
    #a=a.reset_index()
    for i_2 in xrange(1, a.__len__()):
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename'].replace('.txt', '')
        r = a.ix[i_2, 'Filename'].split('/')
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename'].replace('-', '')
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename']+'/'+ r[-1]+ '-xbrl.zip'
    a=a.reset_index()
   
    for i_3 in xrange(a.__len__()):
        urllib.urlretrieve('ftp://ftp.sec.gov/'+a.ix[i_3,'Filename'], destination+'/'+df_path.ix[i_1,'Links'].replce('.zip','_'+str(i_3)+'.zip'))
        zipFilePath_1= destination+'/'+df_path.ix[i_1,'Links'].replce('.zip','_'+str(i_3)+'.zip')
        destDir_1=destination+'/'+df_path.ix[i_1,'Links'].replace('/xbrl.zip','')  
        zfile_1 = zipfile.ZipFile(zipFilePath_1)
        for name_1 in zfile_1.namelist():
            (dirName_1, fileName_1) = os.path.split(name_1)
            if fileName_1 == '':
                # directory
                newDir_1 = destDir_1 + '/' + dirName_1
                if not os.path.exists(newDir_1):
                    os.mkdir(newDir_1)
            else:
                # file
                fd_1 = open(destDir_1 + '/' + name_1, 'wb')
                fd_1.write(zfile.read(name_1))
                fd_1.close()
        zfile_1.close()
        
    
