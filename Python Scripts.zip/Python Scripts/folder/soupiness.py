# -*- coding: utf-8 -*-
"""
Created on Tue May 24 09:07:35 2016

@author: u505119

path = 'C:/Users/u505119/Desktop/hormel_10k.xml'
handle=open(path).read()

tag=data.find('context')
Company_Identification=tag.identifier.string
StartDate=tag.startdate.string
EndDate=tag.enddate.string

"""

#
from bs4 import BeautifulSoup
import lxml
import bs4
from pandas import DataFrame
import csv
import 

frame=DataFrame(columns=['elementId','contextId','unitId','fact','decimals','scale','sign','factId','ns'])
path = 'C:/Users/u505119/Desktop/hormel_10k.xml'
data=BeautifulSoup(open(path))
par=data.findAll()
with open('output.csv', 'w') as csvfile:
    writer = csv.writer(csvfile, delimiter ='|')
    writer.writerow(['elementId','contextId','unitId','fact','decimals','scale','sign','factId','ns'])
    
    for i in result:
        tag = i.attrs
        sentence= i.name +'|'
        if tag.has_key('contextref'):
            sentence= sentence + tag ['contextref'] +'|'
        else:
            sentence= sentence +'|'
            
        if tag.has_key('unitref'):
            sentence= sentence + tag ['unitref'] +'|'
        else:
            sentence= sentence +'|'
            
"""        if tag.has_key('unitref'):
            sentence= sentence + tag ['unitref'] +'|'
        else:
            sentence= sentence +'|'
"""            
        if tag.has_key('decimals'):
            sentence= sentence + tag ['decimals'] +'|'
        else:
            sentence= sentence +'|'
            
        if tag.has_key('unitref'):
            sentence= sentence + tag ['unitref'] +'|'
        else:
            sentence= sentence +'|'
            
        if tag.has_key('unitref'):
            sentence= sentence + tag ['unitref'] +'|'
        else:
            sentence= sentence +'|'
            
            
            
            
            
            writer.writerow([i.name,tag['unitref'])
            
  #elementId|contextId|unitId|fact|decimals|scale|sign|factId|ns  
    
