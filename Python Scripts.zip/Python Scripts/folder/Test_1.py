# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 23:51:10 2016

@author: u505119
"""

#-----------------------------------------------------------------------
#            Calculating Model Parameters
tt=0
tf=0
ff=0
ft=0
cutoff=0.44655
for i in xrange(df.__len__()):
    if df.loc[i,'y']>cutoff:
        if df.loc[i,'actual']=='Yes':
            tt+=1
        else:
            tf+=1
    else:
        if df.loc[i,'actual']=='No':
            ff+=1
        else:
            ft+=1

#-----------------------------------------------------------------------
#            Display of Confution Table
accuracy= str(round(float(tt+ff)*100/float(tt+ff+tf+ft),2))
precision= str(round(float(tt)*100/float(tt+tf),2))
sensitivity= str(round(float(tt)*100/float(tt+ft),2))
specificity= str(round(float(ff)*100/float(tf+ff),2))
npv=str(round(float(ff)*100/float(ft+ff),2))

print '\nConfusion Matrix with threshold as: '+ str(cutoff)+'\n'
print '-----------------------------------------------------------\n'
print '\t  Actual\t\n'
print 'Model\tYes\tNo\t\n'
print 'Yes\t'+str(tt)+'\t'+str(tf)+'\t\t'+'Precision: '+precision+'\n'
print 'No\t'+str(ft)+'\t'+str(ff)+'\t\t'+'NPV: '+npv+'\n'
print 'Sensitivity:\tSpecificity:\tAccuracy:\n'
print sensitivity+'\t\t'+specificity+'\t\t'+accuracy+'\n'

import numpy as np
from sklearn.metrics import roc_auc_score
y_scoresl=[]
for i in xrange(df.__len__()):
    y_scoresl.append([df.loc[i,'y']])
y_scores = np.array(y_scoresl)
y_true =frame.loc[int(frame.__len__()*0.7)+1:frame.__len__(),'Indicator']
y_true=[(item=='Yes') for item in y_true if 1]
print '-----------------------------------------------------------\n'
print 'ROC Score: ' +str(round(roc_auc_score(y_true, y_scores),3))+'\n'
print '-----------------------------------------------------------\n'
