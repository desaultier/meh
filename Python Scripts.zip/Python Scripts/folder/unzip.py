# -*- coding: utf-8 -*-
"""
Created on Wed May 25 15:39:23 2016

@author: u505119
"""

import zipfile
import os.path
import os

zipFilePath= 'C:/Users/u505119/Desktop/Website/xbrl.zip'
destDir='C:/Users/u505119/Desktop/Website'

zfile = zipfile.ZipFile(zipFilePath)
for name in zfile.namelist():
    (dirName, fileName) = os.path.split(name)
    if fileName == '':
        # directory
        newDir = destDir + '/' + dirName
        if not os.path.exists(newDir):
            os.mkdir(newDir)
    else:
        # file
        fd = open(destDir + '/' + name, 'wb')
        fd.write(zfile.read(name))
        fd.close()
zfile.close()
