# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:47:40 2016

@author: u505119
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
from sklearn.metrics import precision_recall_curve
import pandas as pd
import nltk
import nltk.data
from nltk.classify import maxent
from nltk import word_tokenize
from nltk.corpus import stopwords
import pickle
import string
from collections import Counter

date=21

MainPath='C:/Users/U505119/Desktop/'+str(date)+'July2016/'
num=0
PathToStoreClassifier=MainPath+'my_classifier'+str(num)+'.pickle'
f = open(PathToStoreClassifier, 'rb')
classifier = pickle.load(f)
f.close()
frame = pd.read_csv(MainPath+'check.csv')

tt=0
tf=0
ff=0
ft=0
cutoff=0.5
y_scoresl=[]
for i in xrange(frame.__len__()):
    #y_scoresl=y_scoresl.append(frame.loc[i,'y'])
    if frame.loc[i,'y']>cutoff:
        
        if frame.loc[i,'actual']=='Yes':
            tt+=1
        else:
            tf+=1
    else:
        if frame.loc[i,'actual']=='No':
            ff+=1
        else:
            ft+=1

#-----------------------------------------------------------------------
#            Display of Confution Table

accuracy= str(round(float(tt+ff)*100/float(tt+ff+tf+ft),2))
precision= str(round(float(tt)*100/float(tt+tf),2))
sensitivity= str(round(float(tt)*100/float(tt+ft),2))
specificity= str(round(float(ff)*100/float(tf+ff),2))
npv=str(round(float(ff)*100/float(ft+ff),2))

print '\nConfusion Matrix with threshold as: '+ str(cutoff)+'\n'
print '-----------------------------------------------------------\n'
print '\t  Actual\t\n'
print 'Model\tYes\tNo\t\n'
print 'Yes\t'+str(tt)+'\t'+str(tf)+'\t\t'+'Precision: '+precision+'\n'
print 'No\t'+str(ft)+'\t'+str(ff)+'\t\t'+'NPV: '+npv+'\n'
print 'Sensitivity:\tSpecificity:\tAccuracy:\n'
print sensitivity+'\t\t'+specificity+'\t\t'+accuracy+'\n'

y_scoresl=[]
y_scoresl=frame.loc[:,'y']
y_true =frame.loc[:,'actual'] 
y_scores = np.array(y_scoresl)
print '-----------------------------------------------------------\n'
print 'Model Evaluation Metrics\n'
y_true=[(item=='Yes') for item in y_true if 1]
print 'ROC Score: ' +str(round(roc_auc_score(y_true, y_scores),3))+'\n'
precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
print '-----------------------------------------------------------\n'
