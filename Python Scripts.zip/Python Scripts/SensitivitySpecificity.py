# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 15:20:56 2016

@author: u505119
"""

def SenSpec(F,STEPS):
    from numpy import linspace    
    SEN=[]
    SPEC=[]
    
    C=linspace(0, 1,STEPS)
    for o in C:
        tt=0
        tf=0
        ff=0
        ft=0
        for i in xrange(F.__len__()):
            if F.loc[i,'y']>o:
                
                if F.loc[i,'actual']=='Yes':
                    tt+=1
                else:
                    tf+=1
            else:
                if F.loc[i,'actual']=='No':
                    ff+=1
                else:
                    ft+=1
        sen= round(float(tt)*100/float(tt+ft),2)
        spec= round(float(ff)*100/float(tf+ff),2)
        SEN.append(sen)
        SPEC.append(spec)
        
    plt.figure()
    plt.plot(C*100, SEN, label='Sensitivity curve' )
    plt.plot(C*100, SPEC, label='Specificity curve' )
    plt.xlim([0.0, 100.0])
    plt.ylim([0.0, 100])
    plt.xlabel('Cutoff')
    plt.ylabel('Percentage')
    plt.title('Sensitivity Specificity Plot')
    plt.legend(loc="lower right")
    plt.show()
    return C,SEN,SPEC
H,J,I=SenSpec(frame,20)
