# -*- coding: utf-8 -*-
"""
Created on Thu Jun 09 11:49:17 2016

@author: u505119
"""
import pandas as pd
import re

path='C:/Users/U505119/Desktop/10_K/outt2101.csv'
Name_toWrite='C:/Users/U505119/Desktop/Parsed.csv'
frame = pd.read_csv(path)

level1 = re.compile(r'[RrsS][ea][vl][e]') 
level1_1 = re.compile(r'[Aa]ccount')
level2 = re.compile(r'[RrCc][eu][ps][rt][eo]')
level3 = re.compile(r'[%]|[$]')
level4 = re.compile('10% *or *more')
level5 = re.compile('ten *percent *or *more')
level6 = re.compile('[cC]ustomer *[Cc]oncentration')
#SenS1 = re.compile(r'[.!?][\s+][A-Z][^t][^dc][^.]')
#SenS2 = re.compile(r'[( ][1-3a-zA-Z][ *][)t][d*c*]')

df=pd.DataFrame(columns=['qtr','form_type','Company_Name','CIK','Date','Path','Category','Fact'])
master_loci=0

def FindRelevant(ltf,indexs):
    for Sentence in ltf:
        #count=0
        global master_loci
        level1r= (level1.search(Sentence)!=None)
        level1_1r= (level1_1.search(Sentence)!=None)
        #level2r= (level2.search(Sentence)!=None)
        #level3r= (level3.search(Sentence)!=None)
        level4r= (level4.search(Sentence)!=None)
        level5r= (level5.search(Sentence)!=None)
        level6r= (level6.search(Sentence)!=None)
        temp1= (level1r or level1_1r ) and (level4r or level5r or level6r) #and level2r and level3r
        if  temp1:
            if (Sentence.__len__()>500):
                #for char in Sentence:
                #   if char.isalpha():
                #       count += 1
                #if (count/float(Sentence.__len__()) > 0.02):
                if level4r or level5r :
                    df.loc[master_loci]=[frame.ix[indexs,'qtr'],frame.ix[indexs,'form_type'],frame.ix[indexs,'Company_Name'],frame.ix[indexs,'CIK'],frame.ix[indexs,'Date.Filed'],frame.ix[indexs,'Path'],'No',Sentence]
                    master_loci +=1                            
                    #print Sentence + '\n\n' 
                    
            else:
                df.loc[master_loci]=[frame.ix[indexs,'qtr'],frame.ix[indexs,'form_type'],frame.ix[indexs,'Company_Name'],frame.ix[indexs,'CIK'],frame.ix[indexs,'Date.Filed'],frame.ix[indexs,'Path'],'No',Sentence]
                master_loci +=1                            
                #print Sentence + '\n\n'

def Find_Pattern(Pattern,thingToFindIn,Print,ind):
    Output=[]
    prev = 0
    for m in re.finditer(Pattern,thingToFindIn): # Ltd or Inc 
        temp=m.start()
        
        if (thingToFindIn[(temp-3):temp] !='Ltd') and (thingToFindIn[(temp-3):temp] !='Inc') and (thingToFindIn[(temp-1):temp+2]!= 'U.S') and (thingToFindIn[(temp-2):temp] !='Dr') and (thingToFindIn[(temp-1):temp+2] !='S.A'):
            Output.append(thingToFindIn[prev:temp+1].lstrip('. '))
            prev = m.start()+1
    Output.append(thingToFindIn[prev:].lstrip('. ').rstrip(' '))
    Output = filter(None, Output)
    Output = list(set(Output))
    if Print:
        FindRelevant(Output,ind)
    return Output
                                
frame = frame[pd.notnull(frame['fact'])]   
list_1=[]     
            
for searchi in xrange(frame.ix[:,'fact'].__len__()):
    try:    
        content=frame.loc[searchi,'fact']
        if (content[0]=='<'):    
            #data=frame.ix[searchi,'fact']
            udata=content.decode("utf-8")
            asciidata=udata.encode("ascii","ignore")
            list_t=re.sub('<.*?>', ' ',asciidata)
            list_t=re.sub('&.{0,10}?;', '',list_t)
            prev = 0
            list_t=list_t.replace('\r',' ').replace('\t',' ').replace('\n',' ')
            list_t=re.sub(' +',' ',list_t)
            list_1.extend(Find_Pattern('[\.]\s*[A-Z(]',list_t,True,searchi))
            
            
            
            
            
            '''temp=Find_Pattern('[\.!\?][\s*][A-Z]',list_t,False,searchi)
            for i in temp:
                temp_1=Find_Pattern(r'[ ][(][a-z1-9A-Z][)]',i,False,searchi)
            for i in temp_1:
                if ('Ltd.' in i) or ('Inc.'in i):
                    list_1.extend(Find_Pattern(r'[a-z0-9][.][A-Z)]',i,True,searchi))
                else:
                    list_1.extend(Find_Pattern('[a-z0-9][\.*][A-Z)]',i,True,searchi))'''
    except:
        continue
#df.drop_duplicates('Fact', take_last=True)
#df=df.reset_index(drop=True)
df.to_csv(Name_toWrite, index=False,mode='wb', sep=',', header=True)








            
'''            
        for i in temp:
            temp_1=Find_Pattern(r'[ ][(][a-z1-9A-Z][)]',i,False)
        for i_2 in temp_1:
            if ('Ltd.' in i_2) or ('Inc.'in i_2):
                list_1.extend(Find_Pattern(r'[a-z0-9][.][A-Z)]',i_2,True))
            else:
                list_1.extend(Find_Pattern(r'[a-z0-9][.*][A-Z)]',i_2,True))            

list_2=[]
for level2i in list_1:
    #list_2.extend(Find_Pattern(r'[ ][(][a-z1-9][)]',level2i,True))
    if ('Ltd.' in level2i) or ('Inc.'in level2i):
        list_2.extend(Find_Pattern(r'[a-z][.][A-Z)]',level2i,True))
    else:
        list_2.extend(Find_Pattern(r'[a-z][.*][A-Z)]',level2i,True))





temp=BeautifulSoup(frame.ix[searchi,'fact'])
list_t=u''
list_temp=temp.findAll()
new_list=[]
list_1=[]
for i in xrange(list_temp.__len__()):
    list_temp[i]=list_temp[i].name

[new_list.append(x) for x in list_temp if x not in new_list]
list_temp=[]


for pi_t in new_list:
    for pi in temp.findAll(pi_t):
        temp_obj= pi.text.encode('ascii', 'ignore').decode('ascii') in list_t        
        if not temp_obj:
            list_t= list_t +' '+ pi.text.encode('ascii', 'ignore').decode('ascii').strip()
    list_t=list_t+ '. ' 

for pi in temp.findAll(new_list[0]):
    list_t= list_t +' '+ pi.text.encode('utf-8', 'ignore').decode('utf-8').strip()
    #list_t=list_t+ '. ' '''
# (r'[.!?][\s*][A-Z(][a-z 1-9][^dc][^.]|[I][n][^c]'
#list_t=re.sub('&#160;',' ',list_t)
#list_t=re.sub('&nbsp;',' ',list_t)
#list_t.replace(u'\xc2', ' ')
#list_t=re.sub('\xc2',' ',list_t)
#list_t.replace(u'\xa0', ' ')
#list_t=re.sub('\xa0',' ',list_t)
#list_t=re.sub('' ',list_t)