# -*- coding: utf-8 -*-
"""
Created on Mon May 23 16:08:01 2016

@author: U505118
"""
import bs4
from bs4 import BeautifulSoup
import pandas as pd
import csv
import unicodedata

path = 'C:/Users/U505119/Desktop/hormel_10k.xml'
handle = open(path)

soup = BeautifulSoup(handle)

result = soup.findAll()

with open('Test.csv', 'w') as csvfile:
    writer = csv.writer(csvfile, delimiter =' ')
    writer.writerow(['elementId|','contextId|','unitId|','fact|'])
    
    for i in result[4:]:
        tag = i.attrs
        sen = i.name+'|'
        
        if tag.has_key('contextref'):
            sen = sen+tag['contextref']+'|'
        elif tag.has_key('id'):
            sen = sen+tag['id']+'|'
        else:
            sen = sen+'|'
        if tag.has_key('unitref'):
            sen = sen + tag['unitref']+'|'
        else:
            sen = sen+'|'
        if i.text.encode('ascii','ignore') != None:
            t = i.text.encode('ascii','ignore').split('\n')
            te = ''.join(t)
            sen = sen + te +'|'
        else:
            sen = sen + '|'
        
        sen.strip()
        writer.writerow([sen])
            
            
    
    