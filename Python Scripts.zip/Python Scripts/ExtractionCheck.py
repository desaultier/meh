# -*- coding: utf-8 -*-
"""
Created on Mon May 30 09:55:08 2016

@author: u505119
"""

import zipfile
import os.path
import os


zipFilePath_1='C:/Users/u505119/Downloads/0001000180-15-000027-xbrl.zip'
destDir_1=  'C:/Users/u505119/Downloads/'
zfile_1 = zipfile.ZipFile(zipFilePath_1)
for name_1 in zfile_1.namelist():
    (dirName_1, fileName_1) = os.path.split(name_1)
    if fileName_1 == '':
        # directory
        newDir_1 = destDir_1 + '/' + dirName_1
        if not os.path.exists(newDir_1):
            os.mkdir(newDir_1)
    else:
        # file
        fd_1 = open(destDir_1 + '/' + name_1, 'wb')
        fd_1.write(zfile_1.read(name_1))
        fd_1.close()
zfile_1.close()
List_to_select=zfile_1.namelist()
#List_to_select=List_to_select.sort()
for i_4 in List_to_select:
    if '.xml' in i_4:
        Name_to_parse=i_4
        break
PATH=destDir_1 +Name_to_parse
Name_toWrite=destDir_1 + '/prsdData0'+'.csv'
