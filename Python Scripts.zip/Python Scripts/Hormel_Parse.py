# -*- coding: utf-8 -*-
"""
Created on Mon May 23 16:08:01 2016

@author: U505118
"""
import bs4
from pandas import DataFrame
import csv
import unicodedata
from bs4 import BeautifulSoup
import pandas as pd


def BasicParse(path):

    df = pd.DataFrame([],columns  = ['elementId', 'contextId', 'unitId', 'fact', 'decimals', 'scale', 'sign', 'factid', 'ns'])
    
    handle = open(path)
    
    soup = BeautifulSoup(handle)
    
    result = soup.findAll()
    y = soup.findAll('xbrl')[0].attrs
    
    Keys=y.keys()
    key_copy=Keys
    
    for index in xrange(key_copy.__len__()):
        key_copy[index]=key_copy[index].lstrip('xlmns:')
    key_copy = filter(None, key_copy)
    for i in xrange(0, result.__len__()):
        tag = result[i].attrs
        sen1 = result[i].name
            
        if tag.has_key('contextref'):
            sen2 = tag['contextref']
        else:
            sen2 = None
            
        if tag.has_key('unitref'):
            sen3 = tag['unitref']
        else:
            sen3 = None
            
        if result[i].text.encode('ascii','ignore') != None:
            t = result[i].text.encode('ascii','ignore').split('\n')
            te = ''.join(t)
            sen4 = te 
        else:
            sen4 = None
            
        if tag.has_key('decimals'):
            sen5 = tag['decimals']
        else:
            sen5 = None
                
        if tag.has_key('scale'):
            sen6 = tag['scale']
        else:
            sen6 = None
                
        if tag.has_key('sign'):
            sen7 = tag['sign']
        else:
            sen7 = None
                
        if tag.has_key('factid'):
            sen8 = tag['factid']
        else:
            sen8 = None
            
        for i_keys in Keys:
            if tag.has_key(i_keys):
                sen9=y[i_keys]
            else:
                if result[i].name.split(':',1)[0] in key_copy:
                    temp_key='xmlns:'+result[i].name.split(':',1)[0]
                    #print temp_key
                    if y.has_key(temp_key):
                        sen9 = y[temp_key]
                        #print '0'
                else:
                    sen9 = None
                    
        df.loc[i] = [sen1,sen2,sen3,sen4,sen5,sen6,sen7,sen8,sen9]
    return df


df = BasicParse('C:/Users/U505119/Desktop/hormel_10k.xml')
df.to_csv('C:/Users/U505119/Desktop/h1_10k.csv', mode='wb', index=False, sep='|')

CIK = df[df['elementId'] == 'identifier'].reset_index().ix[0,'fact'].lstrip('0')
Cname = df[df['elementId'] == 'dei:entityregistrantname'].reset_index().ix[0,'fact']
doc = df[df['elementId'] == 'dei:documenttype'].reset_index().ix[0,'fact']

"""
key_l=tag[0].attrs.keys()
for index in xrange(key_l.__len__()):
    key_l[index]=key_l[index].lstrip('xlmns:')
key_l = filter(None, key_l)
"""    
"""
        if tag.has_key('xmlns'):
            sen9 = y['xmlns']
        elif 'link' in result[i].name:
            sen9 = y['xmlns:link']
        elif 'dei' in result[i].name:
            sen9 = y['xmlns:dei']
        elif 'hrl' in result[i].name:
            sen9 = y['xmlns:hrl']
        elif 'us-gaap' in result[i].name:
            sen9 = y['xmlns:us-gaap']
        elif 'xbrli' in result[i].name:
            sen9 = y['xmlns:xbrli']
        elif 'xbrldi' in result[i].name:
            sen9 = y['xmlns:xbrldi']
        elif 'xlink' in result[i].name:
            sen9 = y['xmlns:xlink']
        elif 'xsi' in result[i].name:
            sen9 = y['xmlns:xsi']
"""

"""
        for i_keys in Keys:
            if tag.has_key(i_keys):
                sen9=y[i_keys]
            else:
                for filtered_i in key_l:
                    if filtered_i in result[i].name:
                        print result[i].name
                        temp_key='xmlns:'+filtered_i
                        if tag.has_key(temp_key):
                            sen9 = y[temp_key]
                            print sen9
                    else:
                        sen9 = None
                        """