# -*- coding: utf-8 -*-
"""
Created on Mon May 23 16:08:01 2016

@author: U505118
"""
import bs4
from bs4 import BeautifulSoup
import pandas as pd
import csv
import unicodedata
from pandas import read_csv

path = 'C:/Users/U505119/Desktop/hormel_10k.xml'
handle = open(path)

soup = BeautifulSoup(handle)

result = soup.findAll()

with open('Test.csv', 'wb') as csvfile:
    writer = csv.writer(csvfile, delimiter =' ',dialect='excel')
    writer.writerow(['elementId|','contextId|','unitId|','fact|','decimals|','scale|','sign|','factId|','ns'])
    
    for i in result[5:]:
        tag = i.attrs
        sen = i.name.strip()+'|' # made a change here
        
        if tag.has_key('contextref'):
            sen = sen+tag['contextref']+'|'
        elif tag.has_key('id'):
            sen = sen+tag['id']+'|'
        else:
            sen = sen+'|'
        if tag.has_key('unitref'):
            sen = sen + tag['unitref']+'|'
        else:
            sen = sen+'|'
        if i.text.encode('ascii','ignore') != None:
            t = i.text.encode('ascii','ignore').split('\n')
            te = ''.join(t)
            sen = sen + te +'|'
        else:
            sen = sen + '|'
        if tag.has_key('decimal'):
            sen = sen + tag['decimal']+'|'
        else:
            sen = sen+'|'
        if tag.has_key('scale'):
            sen = sen + tag['scale']+'|'
        else:
            sen = sen+'|'
        if tag.has_key('sign'):
            sen = sen + tag['sign']+'|'
        else:
            sen = sen+'|'
        if tag.has_key('factid'):
            sen = sen + tag['factid']+'|'
        else:
            sen = sen+'|'
        if tag.has_key('scheme'):
            sen = sen + tag['scheme']
        sen.strip()
        writer.writerow([sen])
            
df=read_csv('C:/Users/U505119/Desktop/Test.csv','Test',delimiter='|')
names=df.columns
names=names.tolist()
for k in xrange(df.columns.__len__()):
   names[k]=names[k].lstrip()
df.columns=names
indexes=df['elementId']=='identifier'
companyCIK=df[indexes].fact.unique().tolist()

    