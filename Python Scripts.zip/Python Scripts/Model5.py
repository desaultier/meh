# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:47:40 2016

@author: u505119
"""
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
import pandas as pd
import pickle
from collections import Counter

#/////////////////////////////////////////////////////////
#                    User Variables
#/////////////////////////////////////////////////////////
#           Paths

MainPath='C:/Users/U505119/Desktop/Maxent/'
PathToSavedClassifier=MainPath+'classifier.pickle'  # Saved MAXENT Classifier
PathToTrainPara=MainPath+'features.pickle'

#           User Controls
##############################################################################################
pathOfParsedSentences='C:/Users/U505119/Desktop/training.csv' # CSV containing extracted sentences and indicator only

CSVlocation=MainPath+'/Extra/check.csv' # Saved Indicator-ProbabilityY-ProbabilityN table from Maxent5.py
# Above CSV HAS TO HAVE FOLLOWING COLUMN NAMES: 'actual' 'y' 'n'
# 'actual' column must have either 'Yes' or 'No' as entries ONLY
# Add following code AFTER READING THE CSV if CSV has column names different than that mentioned above
# frame.columns=['actual','y','n']

useCSVwithSentences=True # Uses saved parsed file with sentences after regulare expression and indicator instead
# If True program uses pathOfParsedSentences, if False program uses CSVlocation

propo=0.7 # Proportion of pathOfParsedSentences to skip if randomise=False

randomise=True # Randomise the sentences before taking the (1-propo)% of pathOfParsedSentences
#Above is in use only when  useCSVwithSentences=True
##############################################################################################
cutoff=0.44572   # Cutoff Probability above which Model assigns Positive
UseOptimumCutoff=True   # Ignores above cutoff and uses's optimal cutoff from sensitivity, specificity curve
##############################################################################################
#           Tables To Display
#ROC: Receiver Operating Characteristic
#SS: Sensitivity Specificity Plot
#L: Lift Table
#G: Gain Table
ROC='T'             # ROC= display?, 'T' if chart is to be displayed
SS='T'              # SS= display? 'T' if chart is to be displayed
L=['T','Total']     # L= [display?,'decile' or 'total'], 'T' if chart is to be displayed
G='T'               # T= display?, 'T' if chart is to be displayed
ShowModelMetrics=True
#############################################################################################
#/////////////////////////////////////////////////////////
#                    User Functions
#/////////////////////////////////////////////////////////
def LiftGainTable(DF,T,F):
    # DF: Dataframe read from CSV
    # T: Total number of Actual Rights 
    # F: Total number of Actual Wrongs    
    deciles=DF.sort('y', ascending=0)   # Sorting table based on Yes Probability in descending order
    deciles=deciles.reset_index(drop=True)  # Reseting indexes to traverse by deciles
    length=deciles.__len__()    # Total Population
    sub=int(length/10)  # Population of each decile
    rem=int(length%10)  # Number of deciles to increse Population by 1 (as total population may not necessarily be divisible by 10)
    popu=[sub for item in xrange(10) if 1]  # Making list of population per decile
    popu[:rem]=[(sub+1) for item in xrange(rem) if 1] # Adding 1 to deciles to remove remainders
    last=0 # Population Traveresed until now
    lift=pd.DataFrame(columns=['0','1','GT','PercentRights','PercentWrongs','PercentPopulation','CumPercentRight','CumPercentPop','LiftAtdecile','TotalLift'])
    lift.loc[0]=[0,0,0,0,0,0,0,0,0,0]   #A dded to make graphs look pretty    
    cumr=0  # Cumulative rights
    cumw=0  # Cumulative Wrongs
    for cin in xrange(10): # As decile
        t0=0    # Number of right per decile, used to calculate decile gain, needed for decile lift
        t1=0    # Number of wrongs per decile
        end=last+popu[cin]  # Decile's ending index
        for i in xrange(last,end):
            if deciles.loc[i,'actual']=='Yes':
                t1+=1
            else:
                t0+=1
        t=t0+t1     # Poulation per decile same as popu[cin]
        cumr+=t1    # Cumulative Rights
        cumw+=t0    # Cumulative Wrongs
        last=end    # Shifting start point for next decile
        pr=(t1*100)/T   # Percentage right wrt to total rights that are present in current decile
        pw=(t0*100)/F   # Percentage wrong wrt to total wrongs that are present in current decile
        pp=(t*100)/length   # Percentage on population in current decile
        pcr=(cumr*100)/T    # Perentage of cumulative rights wrt to total rights up to the current decile
        pcp=(end*100)/length    # Percentage of Population traversed till now 
        ld=(pr*100)/pp  # Lift at current decile
        cld=(pcr*100)/pcp   # Total lift 
        lift.loc[cin+1]=[t0,t1,t,pr,pw,pp,pcr,pcp,ld,cld]   # Adding entry of decile to dataframe. Index+1 because we filled first row with 0's
        # lift Dataframe is in the same format as lift Gain Chart at http://www.analyticsvidhya.com/blog/2016/02/7-important-model-evaluation-error-metrics/
    return lift
        
def Lift_Chart(l,select):   # Displays the lift Chart: either per Decile or Total depending on the value assigned to select
    # l: Dataframe output from  LiftGainTable()
    # select: Selects the chart to display: 'decile' or 'total' lift
    plt.figure()
    if select.lower()=='decile':    #Temp stores selection, default is Total Lift
        temp=l.LiftAtdecile
    else:
        temp=l.TotalLift
    plt.plot(l.CumPercentPop,temp, label='Lift curve' )
    plt.plot([0, 100], [100, 100], 'k--')   # Graph of random pick model, used as a refence to see how much better our model does than randomly selecting
    plt.xlim([10.0, 100.0])     # Starting from 10% as 0% population lift cannot be calculated (Div by zero)
    plt.ylim([0.0, max(temp)])    
    plt.xlabel('Cumulative % of Polulation')
    plt.ylabel(select+ ' % Lift')
    plt.title(select+' Lift Chart')
    plt.legend(loc="upper right")   # Upper right as normally the graph has a downward slope near the right end
    plt.show()
    # Sample graph:
    # Decile: http://www.analyticsvidhya.com/wp-content/uploads/2015/01/Liftdecile.png
    # Total: http://www.analyticsvidhya.com/wp-content/uploads/2015/01/Lift.png

    
def Gain_Chart(g):    # Displays the Total Gain Chart
    # g: Dataframe output from  LiftGainTable()
    plt.figure()
    plt.plot(g.CumPercentPop, g.CumPercentRight, label='Gain curve' )
    plt.plot([0, 100], [0, 100], 'k--')     # Graph of random pick model, used as a refence to see how much better our model does than randomly selecting
    plt.xlim([0.0, 100.0])  # Population percentage always between 0 and 100
    plt.ylim([0.0, 100])    # Gain is always between 0 and 100. Curve always starts at 0 and ends at 100. Refer Sample Graph
    plt.xlabel('Cumulative % of Polulation')
    plt.ylabel('Cumulative % of Right')
    plt.title('Gain Chart')
    plt.legend(loc="lower right")   # Lower right as the graph touches 100 at right end
    plt.show()
    # Sample graph:
    # http://www.analyticsvidhya.com/wp-content/uploads/2015/01/CumGain.png   
    
def ROC_Curve(f, t):    # Receiver Operating Characteristic Chart
    # f: False positive rate
    # t: True positive rate    
    plt.figure()
    plt.plot(f, t,label='ROC curve' )
    plt.plot([0, 1], [0, 1], 'k--')     # Graph of random pick model, used as a refence to see how much better our model does than randomly selecting
    plt.xlim([0.0, 1.0])    # False Positive Rate always less than 1
    plt.ylim([0.0, 1.01])   # True POsitive Rate always less than 1 however 1.01 used to visualize the top of the graph better
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")   # Curve finally reaches (1,1) freeing up the lower right corner
    plt.show()
    # Sample Graph:
    # http://www.analyticsvidhya.com/wp-content/uploads/2015/01/ROC.png

def SenSpec(FPR, SEN, C): # Shows Sensitivity vs Cutoff and Specificity vs Cutoff on same graph
    # Point of intersecting of the two graphs is ideal threshold
    # FPR: False Positive Rate
    # SEN: Sensitivity or True Positive Rate
    # C: Thresholds
    plt.figure()
    plt.plot(C, SEN*100, label='Sensitivity curve' )
    plt.plot(C, (1-FPR)*100, label='Specificity curve' ) # Specificity= 1-FalsePositiveRate
    # Sensitivity and Specificity graphs change based on model. If slopes are too steep the values can saturate quickly
    # In such cases, displaying beyond the maximum can reduce the quality of the graph and impair visualization
    if (max(C)-min(C)) > 0.5:
        plt.xlim([0, 1])
    else:
        plt.xlim([0, max(C)+0.05]) # +0.05 for better visualization
    plt.ylim([0.0, 100])
    plt.xlabel('Cutoff Probability')
    plt.ylabel('Percentage')
    plt.title('Sensitivity Specificity Plot')
    plt.legend(loc="lower right")
    plt.show()
    # Sample Graph:
    # http://www.analyticsvidhya.com/wp-content/uploads/2015/01/curves.png
    
def ShowTables(ROC,SS,L,G):
    # ROC: 'T' to show Receiver Operating Characteristic Chart
    # SS:'T' to show Sensitivity vs Cutoff and Specificity vs Cutoff on same graph,
    # l: 'T' to show Lift Chart,'decile' to show decile based, default is 'total'
    # G:'T' to show Cumulative Gains Chart
    global fpr, tpr,thresholds,frame,a
    if ROC=='T':
        ROC_Curve(fpr, tpr)
    if SS=='T':
        SenSpec(fpr,tpr,thresholds)
    if G=='T':
        Gain_Chart(a)
    if L[0]=='T':
        Lift_Chart(a,select=L[1])

#////////////////////////////////////////////////////////
#                    Main program
#////////////////////////////////////////////////////////

#-----------------------------------------------------------------------
#            Loading Classifier
print '\nLoading Maxent Classifier\n'
f = open(PathToSavedClassifier,'rb')   # Reading has to be done in 'rb' Mode
classifier = pickle.load(f)
f.close()

#-----------------------------------------------------------------------
#            Calculating Cutoff Specific Parameters

if useCSVwithSentences:
    print 'Loading DataFrame from ' + pathOfParsedSentences+ '\n'
    sentences = pd.read_csv(pathOfParsedSentences)
    if randomise:
        print 'Taking random samples equal to ' + str((1-propo)*100)+ '% of DataFrame\n'
        sentences = sentences.sample(frac=(1-propo)).reset_index(drop=True)
    else:
        print 'Taking bottom '+ str((1-propo)*100)+ '% of DataFrame\n'
        sentences = sentences.loc[sentences.__len__()*propo+1:sentences.__len__(),:].reset_index(drop=True)
    print 'Loading Features\n' 

    f = open(PathToTrainPara,'rb')   # Reading has to be done in 'rb' Mode
    train_para = pickle.load(f)
    f.close()
    #-----------------------------------------------------------------------
    #            Prepairing Test Data 
    test=[]
    print 'Processing Test Data\n'
    for i in xrange(sentences.__len__()):
        feature={}
        for parai in train_para:
            if parai in sentences.loc[i,'Phrase'].lower():
                value=True
            else:
                value=False
            feature[parai]=value
        test.append(feature)
    
    #-----------------------------------------------------------------------
    #            Classifying Test Data
    answer=[]
    print 'Classifing Test Data\n'
    for featureset in test:
        pdist = classifier.prob_classify(featureset)
        answer.append([pdist.prob('Yes'), pdist.prob('No')])
    print 'Making Dataframe containging acutals, Y-Probability, N-Probability\n'
    frame=pd.DataFrame(columns=['actual','y','n'])
    master=0
    for i in xrange(sentences.__len__()):
        frame.loc[master]=[sentences.loc[i,'Indicator'],answer[master][0],answer[master][1]]
        master+=1
    
else:
    print 'Loading DataFrame from ' + CSVlocation+ '\n' 
    frame = pd.read_csv(CSVlocation)
    
    
y_scores=frame.loc[:,'y']   # Model given probability of yes
y_true =frame.loc[:,'actual'] # Actual Yes or No 
y_scores = np.array(y_scores)
y_true=[(item=='Yes') for item in y_true if 1]  # Coverting from Yes No to True and False
y_true_count=Counter(y_true).items() # Clusters True and false together in an tuple and gives its freq
if y_true_count[0][0]: 
    yT=y_true_count[0][1]
    fT=y_true_count[1][1]
else:
    yT=y_true_count[1][1]
    fT=y_true_count[0][1]

Score=str(round(roc_auc_score(y_true, y_scores),3)) # Area under ROC
# Score Ranges and Model Evaluation
# 0.90-1 = excellent (A)
# 0.80-.90 = good (B)
# 0.70-.80 = fair (C)
# 0.60-.70 = poor (D)
# 0.50-.60 = fail (F)

fpr, tpr, thresholds = metrics.roc_curve(y_true, y_scores)
a=LiftGainTable(frame,yT,fT) # yT= Number of Sentences Actually a Yes , fT= Number of sentences Actually a No 
idx = np.argwhere(np.isclose((1-fpr)*1000,tpr*1000, atol=10)).reshape(-1)
Optimal = round(thresholds[idx[idx.__len__()/2]],3)

# Nomenclature: ModelPrediction Actual
tt=0 # Model predicts True and is Actually True
tf=0 # Model predicts True but is Actually False
ff=0 # Model predicts False and is Actually False
ft=0 # Model Predicts False but is Aactually True

if UseOptimumCutoff:
    cutoff=Optimal
    print 'Using Optimal Cutoff for confusion matrix\n'
output=[]
for i in xrange(frame.__len__()):
    if frame.loc[i,'y']>cutoff:
        output.append((frame.loc[i,'actual'],True))
        if frame.loc[i,'actual']=='Yes':
            tt+=1
        else:
            tf+=1
    else:
        output.append((frame.loc[i,'actual'],False))
        if frame.loc[i,'actual']=='No':
            ff+=1
        else:
            ft+=1

# How parameters are calculated: http://www.analyticsvidhya.com/wp-content/uploads/2015/01/Confusion_matrix.png
#                               Definitions:
# Accuracy : the proportion of the total number of predictions that were correct.
# Positive Predictive Value or Precision : the proportion of positive cases that were correctly identified.
# Negative Predictive Value : the proportion of negative cases that were correctly identified.
# Sensitivity or Recall : the proportion of actual positive cases which are correctly identified.
# Specificity : the proportion of actual negative cases which are correctly identified.
accuracy= str(round(float(tt+ff)*100/float(tt+ff+tf+ft),2))
precision= str(round(float(tt)*100/float(tt+tf),2)) # Same as Positive Predicted Value
sensitivity= str(round(float(tt)*100/float(tt+ft),2))
specificity= str(round(float(ff)*100/float(tf+ff),2))
npv=str(round(float(ff)*100/float(ft+ff),2)) # Negative predicted value

if ShowModelMetrics:
    #-----------------------------------------------------------------------
    #            Calculations of Model Metrics
    print '-----------------------------------------------------------\n'
    print 'Confusion Matrix with threshold as: '+ str(cutoff)+'\n'
    print '-----------------------------------------------------------\n'
    print '\t  Actual\t\n'
    print 'Model\tYes\tNo\t\n'
    print 'Yes\t'+str(tt)+'\t'+str(tf)+'\t\t'+'Precision: '+precision+'\n'
    print 'No\t'+str(ft)+'\t'+str(ff)+'\t\t'+'NPV: '+npv+'\n'
    print 'Sensitivity:\tSpecificity:\tAccuracy:\n'
    print sensitivity+'\t\t'+specificity+'\t\t'+accuracy+'\n'
    print '-----------------------------------------------------------\n'
    print 'Model Evaluation Metrics\n'
    print 'ROC Score: ' +Score
    ShowTables(ROC,SS,L,G)
    print '-----------------------------------------------------------\n'
    print 'Optimal Cutoff: '+str(Optimal)+'\n'

#-----------------------------------------------------------------------------------------------
#                                END        OF         CODE
#-----------------------------------------------------------------------------------------------



























































'''
import nltk.data
import nltk
from nltk.classify import maxent
from nltk import word_tokenize
from nltk.corpus import stopwords
import string
from collections import Counter
##################################################
plt.clf()
plt.plot(recall, precision, label='Precision-Recall curve')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.ylim([0.0, 1.05])
plt.xlim([0.0, 1.0])
plt.legend(loc="lower left")
plt.show()
##################################################

def lift_chart(DF,C):
    deciles=DF.sort('y', ascending=0)
    length=deciles.__len__()
    sub=int(length/10)
    rem=int(length%10)
    popu=[sub for item in xrange(10) if 1]
    popu[:rem]=[(sub+1) for item in xrange(rem) if 1]
    last=0
    lift=pd.DataFrame(columns=['0','1','GT','%Rights','%Wrongs','%Population','Cum%Right','Cum%Pop','Lift@decile','Total Lift'])
    for cin in xrange(10):
        tt=0
        tf=0
        ff=0
        ft=0
        y_scoresl=[]
        for i in xrange(frame.__len__()):
            #y_scoresl=y_scoresl.append(frame.loc[i,'y'])
            if frame.loc[i,'y']>cutoff:
            
                if frame.loc[i,'actual']=='Yes':
                    tt+=1
                else:
                    tf+=1
            else:
                if frame.loc[i,'actual']=='No':
                    ff+=1
                else:
                    ft+=1
        
####################################################
def SenSpec_Curve(f, t):
    plt.figure()
    plt.plot(1-f, t,label='Sensitivity Specificity Curve' )
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Specificity')
    plt.ylabel('Sensiticity')
    plt.title('Sensitivity Specificity Characteristic')
    plt.legend(loc="lower right")
    plt.show()

###############################################
def SenSpec(F,STEPS):
    from numpy import linspace    
    SEN=[]
    SPEC=[]
    C=linspace(0, 1,STEPS)
    for o in C:
        tt=0
        tf=0
        ff=0
        ft=0
        for i in xrange(F.__len__()):
            if F.loc[i,'y']>o:
                
                if F.loc[i,'actual']=='Yes':
                    tt+=1
                else:
                    tf+=1
            else:
                if F.loc[i,'actual']=='No':
                    ff+=1
                else:
                    ft+=1
        sen= round(float(tt)*100/float(tt+ft),2)
        spec= round(float(ff)*100/float(tf+ff),2)
        SEN.append(sen)
        SPEC.append(spec)
    plt.figure()
    plt.plot(C*100, SEN, label='Sensitivity curve' )
    plt.plot(C*100, SPEC, label='Specificity curve' )
    plt.xlim([0.0, 100.0])
    plt.ylim([0.0, 100])
    plt.xlabel('Cutoff')
    plt.ylabel('Percentage')
    plt.title('Sensitivity Specificity Plot')
    plt.legend(loc="lower right")
    plt.show()
    return C,SEN,SPEC
#######################################################
    fo = open(PathToTrainPara, 'rb')
    train_para=fo.readlines()
    train_para=[item.rstrip('\r\n\)').lstrip('\(') for item in train_para if 1]
    fo.close()

'''