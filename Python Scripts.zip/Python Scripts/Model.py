# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:47:40 2016

@author: u505119
"""
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
import pandas as pd
import pickle
#/////////////////////////////////////////////////////////
#                    User Variables
#/////////////////////////////////////////////////////////
date='21'

MainPath='C:/Users/U505119/Desktop/'+date+'July2016/'
PathToSavedClassifier=MainPath+'my_classifier0.pickle'  # Saved Classifier
CSVlocation=MainPath+'check.csv' # Saved Indicator-ProbabilityY-ProbabilityN table from Maxent5.py

cutoff=0.4  # Cutoff Probability above which Model assigns Positive

#           Tables To Display
#ROC: Receiver Operating Characteristic
#SS: Sensitivity Specificity Plot
#L: Lift Table
#G: Gain Table
ROC='T'             # ROC= display?
SS=['T',10]         # SS= [display?,NumberOfPointsToCalculate]
L=['T','Total']    # L= [display?,'decile' or 'total']
G='T'               # T= display?

#/////////////////////////////////////////////////////////
#                    User Functions
#/////////////////////////////////////////////////////////
def LiftGainTable(DF,T,F):
    deciles=DF.sort('y', ascending=0)   # Sorting table based on Yes Probability in descending order
    deciles=deciles.reset_index(drop=True)  # Reseting indexes to traverse by deciles
    length=deciles.__len__()    #Total Population
    sub=int(length/10)  #Population of each decile
    rem=int(length%10)  #Number of deciles to increse Population by 1 (as total population may not necessarily be divisible by 10)
    popu=[sub for item in xrange(10) if 1]  # Making list of population per decile
    popu[:rem]=[(sub+1) for item in xrange(rem) if 1] # Adding 1 to deciles to remove remainders
    last=0 # Population Traveresed until now
    lift=pd.DataFrame(columns=['0','1','GT','PercentRights','PercentWrongs','PercentPopulation','CumPercentRight','CumPercentPop','LiftAtdecile','TotalLift'])
    lift.loc[0]=[0,0,0,0,0,0,0,0,0,0]   #Added to make graphs look pretty    
    cumr=0  #Cumulative rights
    cumw=0  #Cumulative Wrongs
    for cin in xrange(10): # As decile
        t0=0    # Number of right per decile, used to calculate decile gain, needed for decile lift
        t1=0    # NUmber of wrongs per decile
        end=last+popu[cin]
        for i in xrange(last,end):
            if deciles.loc[i,'actual']=='Yes':
                t1+=1
            else:
                t0+=1
        t=t0+t1
        cumr+=t1
        cumw+=t0
        last=end
        pr=(t1*100)/T
        pw=(t0*100)/F
        pp=(t*100)/length
        pcr=(cumr*100)/T
        pcp=(end*100)/length
        ld=(pr*100)/pp
        cld=(pcr*100)/pcp
        lift.loc[cin+1]=[t0,t1,t,pr,pw,pp,pcr,pcp,ld,cld]
    return lift
        
def Lift_Chart(l,select):
    plt.figure()
    if select.lower()=='decile':
        temp=l.LiftAtdecile
    else:
        temp=l.TotalLift
    plt.plot(l.CumPercentPop,temp, label='Lift curve' )
    plt.plot([0, 100], [100, 100], 'k--')
    plt.xlim([10.0, 100.0])
    plt.ylim([0.0, 220])
    plt.xlabel('Cumulative % of Polulation')
    plt.ylabel(select+ ' % Lift')
    plt.title(select+' Lift Chart')
    plt.legend(loc="upper right")
    plt.show()
    
def Gain_Chart(g):    
    plt.figure()
    plt.plot(g.CumPercentPop, g.CumPercentRight, label='Gain curve' )
    plt.plot([0, 100], [0, 100], 'k--')
    plt.xlim([0.0, 100.0])
    plt.ylim([0.0, 100])
    plt.xlabel('Cumulative % of Polulation')
    plt.ylabel('Cumulative % of Right')
    plt.title('Gain Chart')
    plt.legend(loc="lower right")
    plt.show()
    
def ROC_Curve(f, t):
    plt.figure()
    plt.plot(f, t,label='ROC curve' )
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")
    plt.show()

def SenSpec(FPR, SEN, C):
    plt.figure()
    plt.plot(C*100, SEN*100, label='Sensitivity curve' )
    plt.plot(C*100, (1-FPR)*100, label='Specificity curve' )
    plt.xlim([0.0, 100.0])
    plt.ylim([0.0, 100])
    plt.xlabel('Cutoff')
    plt.ylabel('Percentage')
    plt.title('Sensitivity Specificity Plot')
    plt.legend(loc="lower right")
    plt.show()
    
def ShowTables(ROC,SS,L,G):
    global fpr, tpr,thresholds,frame,a
    if ROC=='T':
        ROC_Curve(fpr, tpr)
    if SS[0]=='T':
        SenSpec(fpr,tpr,thresholds)
    if G=='T':
        Gain_Chart(a)
    if L[0]=='T':
        Lift_Chart(a,select=L[1])

#////////////////////////////////////////////////////////
#                    Main program
#////////////////////////////////////////////////////////

#-----------------------------------------------------------------------
#            Loading Classifier

f = open(PathToSavedClassifier, 'rb')
classifier = pickle.load(f)
f.close()

#-----------------------------------------------------------------------
#            Calculating Cutoff Specific Parameters

frame = pd.read_csv(CSVlocation)
tt=0
tf=0
ff=0
ft=0
y_scoresl=[]
for i in xrange(frame.__len__()):
    if frame.loc[i,'y']>cutoff:
        
        if frame.loc[i,'actual']=='Yes':
            tt+=1
        else:
            tf+=1
    else:
        if frame.loc[i,'actual']=='No':
            ff+=1
        else:
            ft+=1

accuracy= str(round(float(tt+ff)*100/float(tt+ff+tf+ft),2))
precision= str(round(float(tt)*100/float(tt+tf),2))
sensitivity= str(round(float(tt)*100/float(tt+ft),2))
specificity= str(round(float(ff)*100/float(tf+ff),2))
npv=str(round(float(ff)*100/float(ft+ff),2))

y_scoresl=[]
y_scoresl=frame.loc[:,'y']
y_true =frame.loc[:,'actual'] 
y_scores = np.array(y_scoresl)
y_true=[(item=='Yes') for item in y_true if 1]
Score=str(round(roc_auc_score(y_true, y_scores),3))

fpr, tpr, thresholds = metrics.roc_curve(y_true, y_scores)
a=LiftGainTable(frame,tt+ft,tf+ff)

#-----------------------------------------------------------------------
#            Calculations of Model Metrics

print '\nConfusion Matrix with threshold as: '+ str(cutoff)+'\n'
print '-----------------------------------------------------------\n'
print '\t  Actual\t\n'
print 'Model\tYes\tNo\t\n'
print 'Yes\t'+str(tt)+'\t'+str(tf)+'\t\t'+'Precision: '+precision+'\n'
print 'No\t'+str(ft)+'\t'+str(ff)+'\t\t'+'NPV: '+npv+'\n'
print 'Sensitivity:\tSpecificity:\tAccuracy:\n'
print sensitivity+'\t\t'+specificity+'\t\t'+accuracy+'\n'
print '-----------------------------------------------------------\n'
print 'Model Evaluation Metrics\n'
print 'ROC Score: ' +Score#+'\n'
ShowTables(ROC,SS,L,G)
#SenSpec_Curve(fpr, tpr)
print '-----------------------------------------------------------\n'

#-----------------------------------------------------------------------------------------------
#                                END        OF         CODE
#-----------------------------------------------------------------------------------------------















'''
import nltk.data
import nltk
from nltk.classify import maxent
from nltk import word_tokenize
from nltk.corpus import stopwords
import string
from collections import Counter
##################################################
plt.clf()
plt.plot(recall, precision, label='Precision-Recall curve')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.ylim([0.0, 1.05])
plt.xlim([0.0, 1.0])
plt.legend(loc="lower left")
plt.show()
##################################################

def lift_chart(DF,C):
    deciles=DF.sort('y', ascending=0)
    length=deciles.__len__()
    sub=int(length/10)
    rem=int(length%10)
    popu=[sub for item in xrange(10) if 1]
    popu[:rem]=[(sub+1) for item in xrange(rem) if 1]
    last=0
    lift=pd.DataFrame(columns=['0','1','GT','%Rights','%Wrongs','%Population','Cum%Right','Cum%Pop','Lift@decile','Total Lift'])
    for cin in xrange(10):
        tt=0
        tf=0
        ff=0
        ft=0
        y_scoresl=[]
        for i in xrange(frame.__len__()):
            #y_scoresl=y_scoresl.append(frame.loc[i,'y'])
            if frame.loc[i,'y']>cutoff:
            
                if frame.loc[i,'actual']=='Yes':
                    tt+=1
                else:
                    tf+=1
            else:
                if frame.loc[i,'actual']=='No':
                    ff+=1
                else:
                    ft+=1
        
####################################################
def SenSpec_Curve(f, t):
    plt.figure()
    plt.plot(1-f, t,label='Sensitivity Specificity Curve' )
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Specificity')
    plt.ylabel('Sensiticity')
    plt.title('Sensitivity Specificity Characteristic')
    plt.legend(loc="lower right")
    plt.show()

###############################################
def SenSpec(F,STEPS):
    from numpy import linspace    
    SEN=[]
    SPEC=[]
    C=linspace(0, 1,STEPS)
    for o in C:
        tt=0
        tf=0
        ff=0
        ft=0
        for i in xrange(F.__len__()):
            if F.loc[i,'y']>o:
                
                if F.loc[i,'actual']=='Yes':
                    tt+=1
                else:
                    tf+=1
            else:
                if F.loc[i,'actual']=='No':
                    ff+=1
                else:
                    ft+=1
        sen= round(float(tt)*100/float(tt+ft),2)
        spec= round(float(ff)*100/float(tf+ff),2)
        SEN.append(sen)
        SPEC.append(spec)
    plt.figure()
    plt.plot(C*100, SEN, label='Sensitivity curve' )
    plt.plot(C*100, SPEC, label='Specificity curve' )
    plt.xlim([0.0, 100.0])
    plt.ylim([0.0, 100])
    plt.xlabel('Cutoff')
    plt.ylabel('Percentage')
    plt.title('Sensitivity Specificity Plot')
    plt.legend(loc="lower right")
    plt.show()
    return C,SEN,SPEC


'''