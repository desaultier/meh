# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 09:59:45 2016

@author: u505119
"""

tt=0
tf=0
ff=0
ft=0
cutoff=0.3
for i in xrange(df.__len__()):
    if df.loc[i,'y']>cutoff:
        if df.loc[i,'actual']=='Yes':
            tt+=1
        else:
            tf+=1
    else:
        if df.loc[i,'actual']=='No':
            ff+=1
        else:
            ft+=1
