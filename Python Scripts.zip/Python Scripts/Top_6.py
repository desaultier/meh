# -*- coding: utf-8 -*-
"""
Created on Fri May 27 13:08:57 2016

@author: u505119
"""
from pandas import DataFrame
from pandas import read_table
from bs4 import BeautifulSoup
import pandas as pd
import urllib
import zipfile
import os.path
import os
import csv

#/////////////////////////////////////////////////////////
#                    User Variables
#/////////////////////////////////////////////////////////

destination='C:/Users/u505119/Desktop/Edgar'# Path to local Folder
YQ=['16,1'] # Format 'YR,QR,QR,QR,QR'
Read_N_Company=4 # Number of companies who's xbrl has to be parsed
Companies_per_csv=300 # Number of companies per csv
LastSave_df=DataFrame(columns=['Filename','i_1','i_3'])

#/////////////////////////////////////////////////////////
#                    Defined Functions
#/////////////////////////////////////////////////////////

def BasicParse(path):
    df = pd.DataFrame([],columns  = ['elementId', 'contextId', 'unitId', 'fact', 'decimals', 'scale', 'sign', 'factid', 'ns'])
    handle = open(path)
    soup = BeautifulSoup(handle)
    Found_xml=0
    result = soup.findAll()
    for Index_Search_XML in xrange(5):
        if 'xbrl' in result[Index_Search_XML].name:
            print 'XML ns Values Extracted from' + path.split('/')[-1]
            Found_xml=Index_Search_XML
            break
        else:
            y=[]
            Keys=[]
    # Entire content is between xbrl tags, attributes of the xbrl tag
    # is a dictionary containing ns values
    y=result[Found_xml].attrs
    Keys=y.keys()
    # Copy name to remove 'xlmns:' from key names
    key_copy=Keys
    # stripping xlmns and removing Null elements
    for index in xrange(key_copy.__len__()):
        key_copy[index]=key_copy[index].lstrip('xlmns:')
    key_copy = filter(None, key_copy)
    # Finding and feeding values to output dataframe
    for i in xrange(0, result.__len__()):
        tag = result[i].attrs 
        if 'contextref' in tag.keys():
            sen1 = result[i].name # ElementId
            if tag.has_key('contextref'):
                sen2 = tag['contextref']
            else:
                sen2 = None 
            if tag.has_key('unitref'):
                sen3 = tag['unitref']
            else:
                sen3 = None
            # converting text from unicode to ascii
            if result[i].text.encode('ascii','ignore') != None:
                t = result[i].text.encode('ascii','ignore').split('\n')
                te = ''.join(t)
                sen4 = te 
            else:
                sen4 = None
            if tag.has_key('decimals'):
                sen5 = tag['decimals']
            else:
                sen5 = None
            if tag.has_key('scale'):
                sen6 = tag['scale']
            else:
                sen6 = None
            if tag.has_key('sign'):
                sen7 = tag['sign']
            else:
                sen7 = None
            if tag.has_key('factid'):
                sen8 = tag['factid']
            else:
                sen8 = None
            # Mapping Keys to links
            if Keys.__len__():  
                for i_keys in Keys:
                    if tag.has_key(i_keys):
                        sen9=y[i_keys]
                    else:
                        # if the tag name is "us-gaap:xyz" we extract "us-gaap"
                        if result[i].name.split(':',1)[0] in key_copy:
                            temp_key='xmlns:'+result[i].name.split(':',1)[0]
                            #print temp_key
                            if y.has_key(temp_key):
                                sen9 = y[temp_key]
                                #print '0'
                        else:
                            sen9 = None
            else:
                sen9= None
            # Adding to dataframe
            df.loc[i] = [sen1,sen2,sen3,sen4,sen5,sen6,sen7,sen8,sen9]
    df=df.reset_index(drop=True)
    return df
    
def check_dir_exist(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def check_if_already(file_path):
    if os.path.exists(file_path):
        return True
    else:
        return False

#////////////////////////////////////////////////////////
#                    Main program
#////////////////////////////////////////////////////////  

# Initialization
df_path=DataFrame(columns=['Links'])
base='ftp://ftp.sec.gov/edgar/full-index/'

# DataFrame for easy navigation of website and local files
for Index_YQ in xrange(YQ.__len__()):
    temp_YQ=YQ[Index_YQ].split(',')
    site='20'+ str(temp_YQ[0]) + '/'
    for Inner_YQ in xrange(1,temp_YQ.__len__()):
        df_path=df_path.append(DataFrame([site+'QTR'+str(Inner_YQ)+'/xbrl.zip'],columns=['Links']))
df_path=df_path.reset_index(drop=True)
print 'Path dataframe initialized'


for i_1 in xrange(df_path.__len__()):
    #-----------------------------------------------------------------------
    #            Downloading  xbrl.zip from sec.gov 
    # link: 'ftp://ftp.sec.gov/edgar/full-index/YEAR/QTR/xbrl.zip'
    # zipFilePath: 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/xbrl.zip'
    zipFilePath= destination+'/'+df_path.ix[i_1,'Links']    
    check_dir_exist(destination+'/'+df_path.ix[i_1,'Links'].strip('/xbrl.zip'))
    check_temp_0=check_if_already(zipFilePath)
    # If file already exists then dont download
    if not check_temp_0:
        urllib.urlretrieve(base+df_path.ix[i_1,'Links'], zipFilePath)
    
    #-----------------------------------------------------------------------
    #               Extracting  xbrl.zip
    # destDir: 'C:/Users/u505119/Desktop/EdgarYEAR/QTR/'
    destDir=destination+'/'+df_path.ix[i_1,'Links'].replace('xbrl.zip','')
    # zipFilePath: 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/xbrl.zip'
    zfile = zipfile.ZipFile(zipFilePath)
    check_temp_0=check_if_already(destDir + '/' + zfile.namelist()[0])
    # if the zip file has subfolders we make the subfolders and copy files to them
    if not check_temp_0:
        for name in zfile.namelist():
            (dirName, fileName) = os.path.split(name)
            if fileName == '':
                # directory
                newDir = destDir + dirName
                if not os.path.exists(newDir):
                    os.mkdir(newDir)
            else:
                # file
                fd = open(destDir + name, 'wb')
                fd.write(zfile.read(name))
                fd.close()
        zfile.close()
        print 'extracted'+ df_path.ix[i_1,'Links']
    
    #-----------------------------------------------------------------------
    #               Reading IDX File 
    # 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/name'
    a=read_table(destDir + '/' + name,delimiter='|',header=4)
    # Dropping dashes
    a=a.drop(0)
    # Extracting location of company xbrl files on EDGAR
    for i_2 in xrange(1,a.__len__()):
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename'].replace('.txt', '')
        r = a.ix[i_2, 'Filename'].split('/')
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename'].replace('-', '')
        a.ix[i_2, 'Filename'] = a.ix[i_2, 'Filename']+'/'+ r[-1]+ '-xbrl.zip'
    a=a.reset_index(drop=True)
    print 'xbrl Links for all companies in '+df_path.ix[i_1,'Links'].strip('/xbrl.zip')+ ' extracted'
    
    #-----------------------------------------------------------------------
    #               Reading IDX File 
    for i_3 in xrange(Read_N_Company):
        #        Downloading and extracting xbrl files        
        # Link: 'ftp://ftp.sec.gov/Link_in_a'
        # Destination : 'C:/Users/u505119/Desktop/Edgar/YEAR/QTR/filename_index.zip'
        zipFilePath_1= destination+'/'+df_path.ix[i_1,'Links'].replace('.zip','_'+str(i_3)+'.zip')
        destDir_1=destination+'/'+df_path.ix[i_1,'Links'].replace('xbrl.zip','')         
        # Check if the Directory anf the file exists
        check_dir_exist(destination+'/'+df_path.ix[i_1,'Links'].strip('/xbrl.zip'))
        temp_check_1=check_if_already(zipFilePath_1)
        # If file already exists then don't download
        if not temp_check_1:
            urllib.urlretrieve('ftp://ftp.sec.gov/'+a.ix[i_3,'Filename'], zipFilePath_1)
        
        zfile_1 = zipfile.ZipFile(zipFilePath_1)
        #       Selecting proper xbrl file to parse        
        List_to_select=zfile_1.namelist()
        # List ia already sorted and so we select which ever is first but
        # ends in .xml
        for i_4 in List_to_select:
            if '.xml' in i_4:
                Name_to_parse=i_4
                break
            else:
                continue
        PATH=destDir_1 + '/' +Name_to_parse
        temp_check_1=check_if_already(PATH)
        
        if not temp_check_1:
            for name_1 in zfile_1.namelist():
                (dirName_1, fileName_1) = os.path.split(name_1)
                if fileName_1 == '':
                    # directory
                    newDir_1 = destDir_1 + '/' + dirName_1
                    if not os.path.exists(newDir_1):
                        os.mkdir(newDir_1)
                else:
                    # file
                    fd_1 = open(destDir_1 + '/' + name_1, 'wb')
                    fd_1.write(zfile_1.read(name_1))
                    fd_1.close()
            zfile_1.close()
            print 'xbrl files downloaded and extracted of company '+str(i_3)+' in'+ df_path.ix[i_1,'Links'].strip('/xbrl.zip')
            #               Parsing and writing xbrl file
            Temp_DF= BasicParse(PATH)
            check_dir_exist(destDir_1 + '/CSV_Files')
            Name_toWrite=destDir_1 + '/CSV_Files/prsdData'+str(i_3//Companies_per_csv)+'.csv'
            Temp_DF.to_csv(Name_toWrite, mode='a', index=False, sep='|', header=(i_3% Companies_per_csv))
        
        Last_save=destination+'/saved.csv'
        example=csv.writer(open(Last_save, 'wb'), delimiter=',')
        example.writerows( [PATH,i_1,i_3])
#-----------------------------------------------------------------------------------------------
#                                END        OF         CODE
#-----------------------------------------------------------------------------------------------














"""tag_xbrl=soup.findAll('xbrl')
if tag_xbrl.__len__() != 0:
    y = tag_xbrl[0].attrs
    Keys=y.keys()
else:
    y=[]
    Keys=[]
"""
"""
# creating a map to help navigate website and local directy easily
# in the form of YEAR/QTR/FILE
# takes record from 1993 to present year
#for i_0 in xrange(2011,date.today().year+1):
#    site=str(i_0)+'/'
#    for k in xrange(1,5):
#        df_path=df_path.append(DataFrame([site+'QTR'+str(k)+'/xbrl.zip'],columns=['Links']))
df_path=df_path.append(DataFrame([str(2016)+'/QTR'+str(1)+'/xbrl.zip'],columns=['Links']))
# because we appended, index for all will be 0 
"""